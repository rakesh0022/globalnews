<?php
// If user has configured custom widgets, use those (styled by CSS)
if (is_active_sidebar('sidebar-1')) :
  echo '<div class="sidebar-styled">';
  dynamic_sidebar('sidebar-1');
  echo '</div>';
else :
  // Default premium sidebar when no widgets configured
?>

<!-- Trending Widget -->
<div class="sw">
  <div class="sw__head"><div class="sw__bar"></div><h3 class="sw__ttl">Trending Now 🔥</h3></div>
  <div class="sw__body">
    <?php
    $tr = new WP_Query(['posts_per_page'=>5,'orderby'=>'date','order'=>'DESC']);
    $r = 0;
    while ($tr->have_posts()) : $tr->the_post(); $r++; ?>
      <div class="trend-item">
        <div class="trend-rank"><?php echo $r; ?></div>
        <div style="flex:1;min-width:0;">
          <div class="trend-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
          <div class="trend-meta">
            <?php ds_badge(); ?> · <?php ds_ago(); ?>
          </div>
        </div>
      </div>
    <?php endwhile; wp_reset_postdata(); ?>
  </div>
</div>

<!-- Ad: Sidebar -->
<?php ds_ad('ds_ad_sidebar','sb'); ?>

<!-- Newsletter Widget -->
<div class="nl-widget">
  <h3>📬 Get the Daily Scroll</h3>
  <p>Join readers who get the best facts and stories delivered every morning.</p>
  <div class="nl-form">
    <input type="email" class="nl-input" placeholder="Your email address...">
    <button class="nl-btn">Subscribe</button>
  </div>
</div>

<!-- Categories Widget -->
<div class="sw">
  <div class="sw__head"><div class="sw__bar"></div><h3 class="sw__ttl">Browse Topics 🗂️</h3></div>
  <div class="sw__body">
    <div style="display:flex;flex-wrap:wrap;gap:6px;">
      <?php
      $cats = get_categories(['hide_empty'=>false,'number'=>10]);
      $emojis = ['technology'=>'⚡','sports'=>'⚽','business'=>'📈','health'=>'❤️','science'=>'🔬','entertainment'=>'🎬','photography'=>'📸','design'=>'🎨','digital'=>'💻','film'=>'🎬','advertising'=>'📢','podcasts'=>'🎙️'];
      foreach ($cats as $cat) :
        $slug = $cat->slug;
        $emoji = isset($emojis[$slug]) ? $emojis[$slug] : '📄';
      ?>
        <a href="<?php echo get_category_link($cat->term_id); ?>"
           style="display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border-radius:20px;font-size:12.5px;font-weight:600;background:var(--surface-2);color:var(--muted);border:1px solid var(--border-s);transition:all .2s">
          <span><?php echo $emoji; ?></span>
          <?php echo esc_html($cat->name); ?>
          <span style="font-size:10px;color:var(--light);font-weight:700"><?php echo $cat->count; ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php endif; ?>
