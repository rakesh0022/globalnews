<?php get_header(); ?>
<div class="container" style="text-align:center;padding:80px 0">
  <div style="font-size:72px;margin-bottom:16px">🔮</div>
  <h1 style="font-size:44px;font-weight:800;margin-bottom:10px">404</h1>
  <p style="font-size:17px;color:var(--muted);margin-bottom:28px;max-width:380px;margin-left:auto;margin-right:auto">The page you're looking for doesn't exist or has been moved.</p>
  <a href="<?php echo home_url('/'); ?>" style="display:inline-flex;padding:13px 26px;background:var(--grad);color:#fff;font-weight:700;font-size:14px;border-radius:var(--r-sm);box-shadow:0 4px 14px rgba(37,99,235,.3)">← Back to Homepage</a>
</div>
<?php get_footer(); ?>
