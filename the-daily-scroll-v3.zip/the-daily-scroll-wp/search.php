<?php get_header(); ?>
<div class="container">
  <div class="archive-head anim-up"><div style="display:flex;align-items:center;gap:8px;margin-bottom:10px"><div style="width:4px;height:26px;border-radius:4px;background:var(--grad)"></div><span style="font-size:11px;font-weight:800;color:var(--accent);text-transform:uppercase;letter-spacing:.12em">Search</span></div><h1>Results for "<?php echo get_search_query(); ?>"</h1><p style="color:var(--muted);margin-top:4px"><?php global $wp_query; echo $wp_query->found_posts; ?> articles found</p></div>
  <div class="layout-ms"><div>
    <?php if(have_posts()): ?><div class="g3"><?php while(have_posts()): the_post(); ?>
      <article class="card"><div class="card__img"><a href="<?php the_permalink(); ?>"><?php if(has_post_thumbnail()): the_post_thumbnail('card-md'); else: ?><div class="no-thumb">No Image</div><?php endif; ?></a></div><div class="card__body"><div><?php ds_badge(); ?></div><h3 class="card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p class="card__excerpt"><?php echo get_the_excerpt(); ?></p><div class="card__meta"><span><?php the_author(); ?></span><span class="dot"></span><span><?php ds_ago(); ?></span></div></div></article>
    <?php endwhile; ?></div>
    <div class="pagination"><?php the_posts_pagination(['mid_size'=>2]); ?></div>
    <?php else: ?><div style="text-align:center;padding:60px 0"><div style="font-size:48px;margin-bottom:14px">🔍</div><h2>No results found</h2><p style="color:var(--muted)">Try different keywords.</p></div><?php endif; ?>
  </div><aside><?php get_sidebar(); ?></aside></div>
</div>
<?php get_footer(); ?>
