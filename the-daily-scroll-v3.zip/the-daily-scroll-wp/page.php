<?php get_header(); ?>
<div class="container">
<?php if(have_posts()): while(have_posts()): the_post(); ?>
  <div class="pg-head anim-up"><div class="pg-head__label"><div class="pg-head__bar"></div><span>Page</span></div><h1><?php the_title(); ?></h1></div>
  <div class="pg-body"><?php the_content(); ?></div>
<?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>
