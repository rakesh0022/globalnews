<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<?php wp_head(); ?>
<script>(function(){var d=localStorage.getItem('ds_dark');if(d==='1'||(!d&&matchMedia('(prefers-color-scheme:dark)').matches))document.documentElement.classList.add('dark-mode')})()</script>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="search-ov" id="searchOv">
  <button class="search-ov__close" id="searchClose">&times;</button>
  <div class="search-ov__inner">
    <form role="search" method="get" action="<?php echo home_url('/'); ?>">
      <input type="text" name="s" placeholder="Search articles..." value="<?php echo get_search_query(); ?>">
    </form>
  </div>
</div>

<div class="mobile-menu" id="mobMenu">
  <div class="mob-overlay" id="mobOverlay"></div>
  <div class="mob-panel">
    <button class="mob-close" id="mobClose">&times;</button>
    <?php wp_nav_menu(['theme_location'=>'mobile','container'=>false,'fallback_cb'=>function(){
      echo '<a href="'.home_url('/').'">Home</a>';
      foreach(get_categories(['number'=>6,'hide_empty'=>false]) as $c) echo '<a href="'.get_category_link($c->term_id).'">'.esc_html($c->name).'</a>';
    }]); ?>
  </div>
</div>

<header class="site-header glass" id="siteHeader">
  <div class="container">
    <div class="nav-inner">
      <a href="<?php echo home_url('/'); ?>" class="site-logo">
        <div class="logo-icon"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/></svg></div>
        <span class="logo-text">Daily<span class="grad-text">Scroll</span></span>
      </a>
      <nav class="nav-links">
        <?php wp_nav_menu(['theme_location'=>'primary','container'=>false,'items_wrap'=>'%3$s','fallback_cb'=>function(){
          echo '<a href="'.home_url('/').'">Home</a>';
          foreach(get_categories(['number'=>6,'hide_empty'=>false]) as $c) echo '<a href="'.get_category_link($c->term_id).'">'.esc_html($c->name).'</a>';
        }]); ?>
      </nav>
      <div class="nav-actions">
        <button class="nav-btn" id="searchToggle" aria-label="Search"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></button>
        <button class="nav-btn" id="themeToggle" aria-label="Toggle dark mode">
          <svg class="ico-sun" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
          <svg class="ico-moon" style="display:none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
        </button>
        <button class="nav-btn menu-toggle" id="menuToggle" aria-label="Menu"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" d="M4 6h16M4 12h16M4 18h16"/></svg></button>
      </div>
    </div>
  </div>
</header>

<?php if(get_theme_mod('ds_ticker_on') && ($t=get_theme_mod('ds_ticker_text',''))): ?>
<div class="ticker"><div class="ticker-inner">
  <div class="ticker-label"><span class="dot"></span><span>Breaking</span></div>
  <div class="ticker-track"><div class="ticker-scroll">
    <a href="#"><?php echo esc_html($t); ?></a><a href="#"><?php echo esc_html($t); ?></a>
  </div></div>
</div></div>
<?php endif; ?>

<main>
