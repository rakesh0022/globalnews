<?php if(post_password_required()) return; ?>
<div id="comments" class="comments-area">
  <?php if(have_comments()): ?>
    <h2 style="font-size:20px;margin-bottom:20px"><?php printf(_n('One Comment','%s Comments',get_comments_number(),'daily-scroll'),number_format_i18n(get_comments_number())); ?></h2>
    <ol style="list-style:none;padding:0"><?php wp_list_comments(['style'=>'ol','short_ping'=>true,'avatar_size'=>44]); ?></ol>
    <?php the_comments_navigation(); ?>
  <?php endif; ?>
  <?php comment_form(['class_form'=>'comment-form','title_reply'=>'<h3 style="font-size:18px;margin-bottom:14px">Leave a Comment</h3>','label_submit'=>'Post Comment','class_submit'=>'submit']); ?>
</div>
