<?php
// Category, tag, author, date archives — uses index.php layout
get_template_part('index');
