</main>
<footer class="site-footer">
  <div class="container">
    <div class="ft-grid">
      <div class="ft-col"><h4>News</h4><?php foreach(get_categories(['number'=>6,'hide_empty'=>false]) as $c) echo '<a href="'.get_category_link($c->term_id).'">'.esc_html($c->name).'</a>'; ?></div>
      <div class="ft-col"><h4>Features</h4><a href="<?php echo home_url('/blog/'); ?>">Blog</a><a href="<?php echo home_url('/?s=trending'); ?>">Trending</a><a href="#">Newsletter</a></div>
      <div class="ft-col"><h4>Company</h4><a href="<?php echo home_url('/about/'); ?>">About Us</a><a href="<?php echo home_url('/contact/'); ?>">Contact</a></div>
      <div class="ft-col"><h4>Legal</h4><a href="<?php echo home_url('/privacy-policy/'); ?>">Privacy Policy</a><a href="<?php echo home_url('/terms-of-service/'); ?>">Terms</a><a href="<?php echo home_url('/disclaimer/'); ?>">Disclaimer</a><a href="<?php echo home_url('/dmca/'); ?>">DMCA</a></div>
    </div>
    <div class="ft-bottom">
      <a href="<?php echo home_url('/'); ?>" class="site-logo" style="gap:8px">
        <div class="logo-icon" style="width:26px;height:26px;border-radius:9px"><svg xmlns="http://www.w3.org/2000/svg" style="width:13px;height:13px" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/></svg></div>
        <span class="logo-text" style="font-size:15px">Daily<span class="grad-text">Scroll</span></span>
      </a>
      <span class="ft-copy">&copy; <?php echo date('Y'); ?> The Daily Scroll by Suraj Pandey. All rights reserved.</span>
      <div class="ft-links"><a href="<?php echo home_url('/privacy-policy/'); ?>">Privacy</a><a href="<?php echo home_url('/terms-of-service/'); ?>">Terms</a><a href="<?php echo home_url('/contact/'); ?>">Contact</a></div>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body></html>
