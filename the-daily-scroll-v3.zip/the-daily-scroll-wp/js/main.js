document.addEventListener('DOMContentLoaded', function() {
  // Dark mode
  var tgl = document.getElementById('themeToggle');
  var sun = tgl ? tgl.querySelector('.ico-sun') : null;
  var moon = tgl ? tgl.querySelector('.ico-moon') : null;
  function upIcons() {
    var d = document.documentElement.classList.contains('dark-mode');
    if (sun) sun.style.display = d ? 'none' : 'block';
    if (moon) moon.style.display = d ? 'block' : 'none';
  }
  upIcons();
  if (tgl) tgl.addEventListener('click', function() {
    document.documentElement.classList.toggle('dark-mode');
    localStorage.setItem('ds_dark', document.documentElement.classList.contains('dark-mode') ? '1' : '0');
    upIcons();
  });

  // Mobile menu
  var mt = document.getElementById('menuToggle'), mm = document.getElementById('mobMenu'), mo = document.getElementById('mobOverlay'), mc = document.getElementById('mobClose');
  function openM() { if (mm) mm.classList.add('active'); document.body.style.overflow = 'hidden'; }
  function closeM() { if (mm) mm.classList.remove('active'); document.body.style.overflow = ''; }
  if (mt) mt.addEventListener('click', openM);
  if (mo) mo.addEventListener('click', closeM);
  if (mc) mc.addEventListener('click', closeM);

  // Search
  var st = document.getElementById('searchToggle'), sv = document.getElementById('searchOv'), sc = document.getElementById('searchClose'), si = sv ? sv.querySelector('input') : null;
  function openS() { if (sv) sv.classList.add('active'); if (si) si.focus(); document.body.style.overflow = 'hidden'; }
  function closeS() { if (sv) sv.classList.remove('active'); document.body.style.overflow = ''; }
  if (st) st.addEventListener('click', openS);
  if (sc) sc.addEventListener('click', closeS);
  if (sv) sv.addEventListener('click', function(e) { if (e.target === sv) closeS(); });

  document.addEventListener('keydown', function(e) { if (e.key === 'Escape') { closeS(); closeM(); } });

  // Header shadow
  var hdr = document.getElementById('siteHeader');
  window.addEventListener('scroll', function() {
    if (hdr) hdr.classList.toggle('scrolled', window.scrollY > 10);
  }, { passive: true });

  // Reading progress
  var bar = document.getElementById('readBar');
  if (bar) window.addEventListener('scroll', function() {
    var h = document.documentElement.scrollHeight - window.innerHeight;
    bar.style.width = (h > 0 ? (window.scrollY / h) * 100 : 0) + '%';
  }, { passive: true });

  // Fade-up on scroll
  var els = document.querySelectorAll('.anim-up');
  if ('IntersectionObserver' in window && els.length) {
    var obs = new IntersectionObserver(function(entries) {
      entries.forEach(function(e) {
        if (e.isIntersecting) { e.target.style.opacity = '1'; e.target.style.transform = 'translateY(0)'; obs.unobserve(e.target); }
      });
    }, { threshold: 0.1 });
    els.forEach(function(el) {
      el.style.opacity = '0'; el.style.transform = 'translateY(14px)';
      el.style.transition = 'opacity .45s ease, transform .45s ease';
      obs.observe(el);
    });
  }
});
