<?php
if (!defined('ABSPATH')) exit;

function ds_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', ['height'=>64,'width'=>200,'flex-height'=>true,'flex-width'=>true]);
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption']);
    add_theme_support('automatic-feed-links');
    add_theme_support('responsive-embeds');
    add_theme_support('wp-block-styles');
    add_image_size('hero-lg', 1200, 675, true);
    add_image_size('card-md', 600, 340, true);
    register_nav_menus(['primary'=>'Primary Navigation','mobile'=>'Mobile Navigation']);
}
add_action('after_setup_theme', 'ds_setup');

function ds_scripts() {
    wp_enqueue_style('google-fonts','https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700;9..40,800&display=swap',[],null);
    wp_enqueue_style('ds-style', get_stylesheet_uri(), [], '2.0.0');
    wp_enqueue_script('ds-main', get_template_directory_uri().'/js/main.js', [], '2.0.0', true);
    if (is_singular() && comments_open()) wp_enqueue_script('comment-reply');
}
add_action('wp_enqueue_scripts', 'ds_scripts');

function ds_adsense_head() {
    $id = get_theme_mod('ds_adsense_id','');
    if ($id) echo '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client='.esc_attr($id).'" crossorigin="anonymous"></script>'."\n";
}
add_action('wp_head', 'ds_adsense_head');

function ds_widgets() {
    register_sidebar(['name'=>'Sidebar','id'=>'sidebar-1','before_widget'=>'<div class="sw">','after_widget'=>'</div>','before_title'=>'<div class="sw__head"><div class="sw__bar"></div><h3 class="sw__ttl">','after_title'=>'</h3></div>']);
}
add_action('widgets_init', 'ds_widgets');

function ds_customizer($wp_customize) {
    $wp_customize->add_section('ds_ads', ['title'=>'Google AdSense','priority'=>120]);
    foreach (['ds_adsense_id'=>'AdSense Client ID (ca-pub-XXX)','ds_ad_header'=>'Header Ad Slot','ds_ad_sidebar'=>'Sidebar Ad Slot','ds_ad_article'=>'In-Article Ad Slot'] as $k=>$l) {
        $wp_customize->add_setting($k, ['default'=>'','sanitize_callback'=>'sanitize_text_field']);
        $wp_customize->add_control($k, ['label'=>$l,'section'=>'ds_ads','type'=>'text']);
    }
    $wp_customize->add_section('ds_ticker', ['title'=>'Breaking News','priority'=>110]);
    $wp_customize->add_setting('ds_ticker_on', ['default'=>false,'sanitize_callback'=>'wp_validate_boolean']);
    $wp_customize->add_control('ds_ticker_on', ['label'=>'Enable Breaking Ticker','section'=>'ds_ticker','type'=>'checkbox']);
    $wp_customize->add_setting('ds_ticker_text', ['default'=>'','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('ds_ticker_text', ['label'=>'Ticker Text','section'=>'ds_ticker','type'=>'text']);
}
add_action('customize_register', 'ds_customizer');

function ds_ad($setting, $size='lb') {
    $slot = get_theme_mod($setting,'');
    $client = get_theme_mod('ds_adsense_id','');
    if ($slot && $client) {
        echo '<div class="ad-ph ad-ph--'.$size.'"><ins class="adsbygoogle" style="display:block" data-ad-client="'.esc_attr($client).'" data-ad-slot="'.esc_attr($slot).'" data-ad-format="auto" data-full-width-responsive="true"></ins><script>(adsbygoogle=window.adsbygoogle||[]).push({});</script></div>';
    } else {
        echo '<div class="ad-ph ad-ph--'.$size.'"><span>Advertisement</span></div>';
    }
}

function ds_badge($cat=null) {
    if (!$cat) { $cats=get_the_category(); if(empty($cats)) return; $cat=$cats[0]; }
    $s=is_object($cat)?$cat->slug:sanitize_title($cat);
    $n=is_object($cat)?$cat->name:$cat;
    echo '<span class="cat-badge cat-badge-'.esc_attr($s).'">'.esc_html($n).'</span>';
}

function ds_ago() { echo human_time_diff(get_the_time('U'),current_time('timestamp')).' ago'; }

function ds_readtime() {
    $w = str_word_count(strip_tags(get_post_field('post_content',get_the_ID())));
    echo max(1,ceil($w/200)).' min read';
}

add_filter('excerpt_length', function(){ return 22; });
add_filter('excerpt_more', function(){ return '...'; });

// Force homepage to show latest posts (override static page setting)
function ds_force_blog_home($query) {
    if ($query->is_main_query() && is_front_page() && is_page()) {
        $query->set('post_type', 'post');
        $query->set('page_id', '');
        $query->is_page = false;
        $query->is_home = true;
        $query->is_singular = false;
    }
}
add_action('pre_get_posts', 'ds_force_blog_home');
