<?php get_header(); ?>
<div class="reading-bar"><div class="reading-bar__fill" id="readBar"></div></div>
<div class="container">
<?php if(have_posts()): while(have_posts()): the_post(); ?>

<div class="art-head anim-up">
  <div style="margin-bottom:14px"><?php ds_badge(); ?></div>
  <h1><?php the_title(); ?></h1>
  <?php if(has_excerpt()): ?><p class="art-desc"><?php echo get_the_excerpt(); ?></p><?php endif; ?>
</div>

<div class="art-by">
  <div class="art-by__author">
    <div class="art-by__avatar"><?php echo strtoupper(substr(get_the_author(),0,1)); ?></div>
    <div><div class="art-by__name"><?php the_author(); ?></div><div class="art-by__date"><time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date('M j, Y'); ?></time> · <?php ds_readtime(); ?></div></div>
  </div>
  <div class="share-btns">
    <a class="share-btn" href="https://twitter.com/intent/tweet?text=<?php echo urlencode(get_the_title()); ?>&url=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="noopener"><svg fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></a>
    <a class="share-btn" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="noopener"><svg fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg></a>
    <button class="share-btn" onclick="navigator.clipboard.writeText(location.href);this.title='Copied!'" title="Copy link"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg></button>
  </div>
</div>

<?php if(has_post_thumbnail()): ?><div class="art-img"><?php the_post_thumbnail('hero-lg'); ?></div><?php endif; ?>

<div class="layout-ms">
<div>
  <div class="art-body"><?php the_content(); ?></div>
  <?php ds_ad('ds_ad_article','ia'); ?>
  <?php if(has_tag()): ?><div style="max-width:780px;margin:28px auto 0;display:flex;gap:8px;flex-wrap:wrap;align-items:center"><span style="font-size:12px;font-weight:700;color:var(--light);text-transform:uppercase">Tags:</span><?php the_tags('','',''); ?></div><?php endif; ?>
  <div class="comments-area"><?php if(comments_open()||get_comments_number()) comments_template(); ?></div>
</div>
<aside><?php get_sidebar(); ?></aside>
</div>

<?php
// Related posts
$cats=get_the_category();
if(!empty($cats)):
  $rel=new WP_Query(['category__in'=>[$cats[0]->term_id],'post__not_in'=>[get_the_ID()],'posts_per_page'=>4,'orderby'=>'rand']);
  if($rel->have_posts()): ?>
<section style="margin-top:56px;padding-top:36px;border-top:1px solid var(--border)">
  <div class="sec-head"><div class="sec-head__left"><div class="sec-head__bar"></div><h2 class="sec-head__title">Related Articles</h2></div></div>
  <div class="g4"><?php while($rel->have_posts()): $rel->the_post(); ?>
    <article class="card"><div class="card__img"><a href="<?php the_permalink(); ?>"><?php if(has_post_thumbnail()): the_post_thumbnail('card-md'); else: ?><div class="no-thumb">No Image</div><?php endif; ?></a></div>
    <div class="card__body"><div><?php ds_badge(); ?></div><h3 class="card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><div class="card__meta"><span><?php ds_ago(); ?></span></div></div></article>
  <?php endwhile; ?></div>
</section>
<?php wp_reset_postdata(); endif; endif; ?>

<?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>
