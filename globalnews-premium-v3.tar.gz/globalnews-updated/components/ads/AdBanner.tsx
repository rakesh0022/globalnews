"use client";

import { useEffect, useRef } from "react";

interface Props {
  slot: string;
  format?: "auto" | "horizontal" | "vertical" | "rectangle";
  responsive?: boolean;
  className?: string;
}

/**
 * Google AdSense ad unit component.
 * 
 * Usage:
 *   <AdBanner slot="1234567890" format="auto" responsive />
 *
 * To activate:
 * 1. Replace YOUR_ADSENSE_CLIENT_ID in layout.tsx with your actual client ID
 * 2. Replace slot prop values with real ad unit IDs from your AdSense dashboard
 */
export default function AdBanner({ slot, format = "auto", responsive = true, className = "" }: Props) {
  const adRef = useRef<HTMLModElement>(null);
  const pushed = useRef(false);

  useEffect(() => {
    if (pushed.current) return;
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const adsbygoogle = (window as any).adsbygoogle;
      if (adsbygoogle) {
        adsbygoogle.push({});
        pushed.current = true;
      }
    } catch (e) {
      console.error("AdSense error:", e);
    }
  }, []);

  return (
    <div className={`ad-container overflow-hidden ${className}`}>
      <div className="text-center mb-1">
        <span className="text-[10px] font-medium text-slate-400 dark:text-slate-600 uppercase tracking-widest">
          Advertisement
        </span>
      </div>
      <ins
        ref={adRef}
        className="adsbygoogle"
        style={{ display: "block" }}
        data-ad-client={process.env.NEXT_PUBLIC_ADSENSE_CLIENT_ID || "ca-pub-XXXXXXXXXXXXXXXX"}
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive={responsive ? "true" : "false"}
      />
    </div>
  );
}
