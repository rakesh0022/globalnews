/**
 * Placeholder component shown when AdSense is not yet configured.
 * Replace with <AdBanner> once you have your AdSense account approved.
 */
interface Props {
  size?: "leaderboard" | "sidebar" | "in-article" | "banner";
  className?: string;
}

const SIZES = {
  leaderboard: "h-[90px] sm:h-[90px]",
  sidebar:     "h-[250px]",
  "in-article":"h-[250px]",
  banner:      "h-[60px] sm:h-[90px]",
};

export default function AdPlaceholder({ size = "leaderboard", className = "" }: Props) {
  return (
    <div className={`rounded-xl border border-dashed border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0a1020] flex items-center justify-center ${SIZES[size]} ${className}`}>
      <span className="text-[11px] font-medium text-slate-400 dark:text-slate-600 uppercase tracking-widest">
        Advertisement
      </span>
    </div>
  );
}
