interface Props {
  minutes: number;
  className?: string;
}

export default function ReadingTime({ minutes, className = "" }: Props) {
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium text-slate-400 dark:text-slate-500 ${className}`}>
      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <circle cx="12" cy="12" r="10" />
        <path strokeLinecap="round" d="M12 6v6l4 2" />
      </svg>
      {minutes} min read
    </span>
  );
}
