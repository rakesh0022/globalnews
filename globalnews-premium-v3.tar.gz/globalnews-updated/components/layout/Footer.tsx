import Link from "next/link";

const FOOTER_LINKS = {
  "News": [
    { label: "Technology", href: "/?category=technology" },
    { label: "Business",   href: "/?category=business" },
    { label: "Sports",     href: "/?category=sports" },
    { label: "Health",     href: "/?category=health" },
    { label: "Science",    href: "/?category=science" },
    { label: "Entertainment", href: "/?category=entertainment" },
  ],
  "Features": [
    { label: "Blog",       href: "/blog" },
    { label: "Bookmarks",  href: "/bookmarks" },
    { label: "Trending",   href: "/search?q=trending" },
    { label: "Newsletter", href: "#newsletter" },
  ],
  "Company": [
    { label: "About Us",   href: "/about" },
    { label: "Contact",    href: "/contact" },
    { label: "Advertise",  href: "/contact" },
  ],
  "Legal": [
    { label: "Privacy Policy",    href: "/privacy" },
    { label: "Terms of Service",  href: "/terms" },
    { label: "Disclaimer",        href: "/disclaimer" },
    { label: "DMCA",              href: "/dmca" },
  ],
};

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-slate-200 dark:border-slate-800/60 bg-white dark:bg-[#0d1526]">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12">

        {/* Link grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 mb-10">
          {Object.entries(FOOTER_LINKS).map(([title, links]) => (
            <div key={title}>
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-widest mb-4">
                {title}
              </h3>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link.label}>
                    <Link href={link.href}
                      className="text-sm text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-slate-100 dark:border-slate-800/60 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center shadow-sm">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
              </svg>
            </div>
            <span className="font-bold text-slate-900 dark:text-white">
              News<span className="gradient-text">Hub</span>
            </span>
          </div>

          <p className="text-sm text-slate-400 dark:text-slate-500">
            © {new Date().getFullYear()} NewsHub. All rights reserved.
          </p>

          <div className="flex items-center gap-4 text-sm text-slate-400 dark:text-slate-500">
            <Link href="/privacy" className="hover:text-slate-700 dark:hover:text-slate-200 transition-colors">Privacy</Link>
            <span>·</span>
            <Link href="/terms" className="hover:text-slate-700 dark:hover:text-slate-200 transition-colors">Terms</Link>
            <span>·</span>
            <Link href="/contact" className="hover:text-slate-700 dark:hover:text-slate-200 transition-colors">Contact</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
