import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Disclaimer",
  description: "NewsHub Disclaimer — important information about our content and services.",
};

export default function DisclaimerPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
      <div className="space-y-3 mb-10 animate-fade-up">
        <div className="flex items-center gap-2">
          <div className="w-1 h-7 rounded-full bg-gradient-to-b from-blue-500 to-violet-600" />
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">Legal</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">Disclaimer</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Last updated: April 14, 2026</p>
      </div>
      <article className="prose prose-slate dark:prose-invert max-w-none prose-headings:tracking-tight">
        <h2>General Information</h2>
        <p>The information provided on NewsHub is for general informational purposes only. All content is provided in good faith, however we make no representation or warranty regarding the accuracy, adequacy, validity, reliability, or completeness of any information on the site.</p>
        <h2>News Content</h2>
        <p>NewsHub aggregates news from multiple third-party sources. We are not responsible for the accuracy, completeness, or reliability of content provided by these sources. Articles sourced from external providers reflect the views and reporting of their original publishers.</p>
        <h2>Not Professional Advice</h2>
        <p>The content on NewsHub should not be construed as professional financial, legal, medical, or other advice. Always consult a qualified professional before making decisions based on information you read online.</p>
        <h2>External Links</h2>
        <p>NewsHub may contain links to external websites not operated by us. We have no control over and assume no responsibility for the content or practices of third-party sites.</p>
        <h2>Advertising</h2>
        <p>This site contains third-party advertisements. The appearance of advertisements does not constitute endorsement of the advertised products or services. We are not responsible for the content of advertisements or the products/services they promote.</p>
        <h2>Fair Use</h2>
        <p>NewsHub uses images and content under fair use provisions for news reporting and commentary purposes. If you believe any content infringes on your copyright, please refer to our <a href="/dmca">DMCA Policy</a>.</p>
      </article>
    </div>
  );
}
