import { MetadataRoute } from "next";
import { blogPosts } from "@/lib/blog-data";
import { mockArticles } from "@/lib/mock-data";

const BASE = process.env.NEXT_PUBLIC_BASE_URL || "https://newshub.com";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date().toISOString();

  // Static pages
  const staticPages: MetadataRoute.Sitemap = [
    { url: `${BASE}/`,           lastModified: now, changeFrequency: "hourly",  priority: 1.0 },
    { url: `${BASE}/blog`,       lastModified: now, changeFrequency: "daily",   priority: 0.8 },
    { url: `${BASE}/search`,     lastModified: now, changeFrequency: "daily",   priority: 0.6 },
    { url: `${BASE}/bookmarks`,  lastModified: now, changeFrequency: "weekly",  priority: 0.5 },
    { url: `${BASE}/about`,      lastModified: now, changeFrequency: "monthly", priority: 0.4 },
    { url: `${BASE}/contact`,    lastModified: now, changeFrequency: "monthly", priority: 0.4 },
    { url: `${BASE}/privacy`,    lastModified: now, changeFrequency: "monthly", priority: 0.3 },
    { url: `${BASE}/terms`,      lastModified: now, changeFrequency: "monthly", priority: 0.3 },
    { url: `${BASE}/disclaimer`, lastModified: now, changeFrequency: "monthly", priority: 0.3 },
    { url: `${BASE}/dmca`,       lastModified: now, changeFrequency: "yearly",  priority: 0.2 },
  ];

  // Article pages
  const articlePages: MetadataRoute.Sitemap = mockArticles.map((a) => ({
    url: `${BASE}/article/${a.id}`,
    lastModified: a.publishedAt,
    changeFrequency: "weekly" as const,
    priority: 0.7,
  }));

  // Blog pages
  const blogPages: MetadataRoute.Sitemap = blogPosts.map((p) => ({
    url: `${BASE}/blog/${p.slug}`,
    lastModified: p.updatedAt || p.publishedAt,
    changeFrequency: "weekly" as const,
    priority: 0.7,
  }));

  return [...staticPages, ...articlePages, ...blogPages];
}
