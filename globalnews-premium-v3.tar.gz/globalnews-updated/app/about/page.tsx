import { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "About Us",
  description: "Learn about NewsHub — your modern source for breaking news, in-depth analysis, and personalized coverage.",
};

export default function AboutPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
      <div className="space-y-3 mb-10 animate-fade-up">
        <div className="flex items-center gap-2">
          <div className="w-1 h-7 rounded-full bg-gradient-to-b from-blue-500 to-violet-600" />
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">About</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">About NewsHub</h1>
      </div>

      <article className="prose prose-slate dark:prose-invert max-w-none prose-lg prose-headings:tracking-tight prose-a:text-blue-600 dark:prose-a:text-blue-400">
        <p>
          NewsHub is a modern digital news platform committed to delivering timely, accurate, and relevant news coverage from around the world. We aggregate and curate content spanning technology, business, sports, health, science, entertainment, and more.
        </p>

        <h2>Our Mission</h2>
        <p>
          We believe everyone deserves access to high-quality journalism presented in a clean, distraction-free interface. Our mission is to make staying informed effortless — whether you&apos;re catching up on breaking news during your commute or diving deep into a topic you care about.
        </p>

        <h2>What Makes Us Different</h2>
        <ul>
          <li><strong>Personalized Experience</strong> — Our recommendation engine learns your interests and surfaces stories that matter to you.</li>
          <li><strong>Clean, Modern Design</strong> — No pop-ups, no clutter. Just the news, beautifully presented with full dark mode support.</li>
          <li><strong>Multi-Source Coverage</strong> — We aggregate from trusted news sources worldwide to give you a complete picture.</li>
          <li><strong>Blog & Analysis</strong> — Our editorial team publishes in-depth analysis, opinion pieces, and long-form features.</li>
          <li><strong>Open & Transparent</strong> — We clearly label sources, opinions, and sponsored content.</li>
        </ul>

        <h2>Our Team</h2>
        <p>
          NewsHub is built by a team of journalists, engineers, and designers passionate about the intersection of technology and media. We&apos;re committed to editorial integrity, user privacy, and building the best news reading experience on the web.
        </p>

        <h2>Contact</h2>
        <p>
          Have feedback, tips, or questions? Visit our <Link href="/contact">Contact page</Link> or email us at <a href="mailto:hello@newshub.com">hello@newshub.com</a>.
        </p>
      </article>
    </div>
  );
}
