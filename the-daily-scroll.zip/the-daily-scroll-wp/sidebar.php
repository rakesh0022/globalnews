<?php if (is_active_sidebar('sidebar-1')) : ?>
  <?php dynamic_sidebar('sidebar-1'); ?>
<?php else : ?>

  <!-- Trending Widget -->
  <div class="sidebar-widget">
    <div class="sidebar-widget__header">
      <div class="sidebar-widget__accent"></div>
      <h3 class="sidebar-widget__title">Trending Now 🔥</h3>
    </div>
    <div class="sidebar-widget__body">
      <?php
      $trending = new WP_Query(array(
        'posts_per_page' => 5,
        'orderby'        => 'comment_count',
        'order'          => 'DESC',
      ));
      $rank = 0;
      while ($trending->have_posts()) : $trending->the_post(); $rank++;
      ?>
        <div class="trending-item">
          <div class="trending-item__rank"><?php echo $rank; ?></div>
          <div>
            <div class="trending-item__title">
              <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </div>
            <div class="trending-item__meta"><?php dailyscroll_time_ago(); ?></div>
          </div>
        </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
  </div>

  <!-- Ad: Sidebar -->
  <?php dailyscroll_ad('dailyscroll_ad_slot_sidebar', 'sidebar'); ?>

  <!-- Newsletter Widget -->
  <div class="newsletter-widget">
    <h3>📬 Get the Daily Scroll</h3>
    <p>Join readers who get the best stories delivered to their inbox every morning.</p>
    <div class="newsletter-widget__form">
      <input type="email" class="newsletter-widget__input" placeholder="Your email...">
      <button class="newsletter-widget__btn">Subscribe</button>
    </div>
  </div>

<?php endif; ?>
