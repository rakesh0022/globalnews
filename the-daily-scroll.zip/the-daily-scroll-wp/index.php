<?php get_header(); ?>

<div class="container">

  <?php if (is_front_page() && !is_paged()) : ?>

    <!-- Hero Section -->
    <?php
    $hero_query = new WP_Query(array('posts_per_page' => 4, 'ignore_sticky_posts' => false));
    if ($hero_query->have_posts()) :
      $count = 0;
    ?>
    <section class="hero-section">
      <div class="hero-grid">
        <?php while ($hero_query->have_posts()) : $hero_query->the_post(); $count++; ?>
          <?php if ($count === 1) : ?>
            <div class="hero-main">
              <?php if (has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('hero-large', array('class' => 'hero-main__img')); ?>
              <?php else : ?>
                <div class="hero-main__img" style="background:linear-gradient(135deg,#1e293b,#334155);"></div>
              <?php endif; ?>
              <div class="hero-main__overlay"></div>
              <div class="hero-main__content">
                <?php dailyscroll_category_badge(); ?>
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <div class="hero-main__meta">
                  <span><?php the_author(); ?></span>
                  <span style="opacity:0.5;">·</span>
                  <span><?php dailyscroll_time_ago(); ?></span>
                  <span style="opacity:0.5;">·</span>
                  <span><?php dailyscroll_reading_time(); ?></span>
                </div>
              </div>
            </div>
          <?php else : ?>
            <div class="hero-secondary">
              <?php if (has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('card-medium'); ?>
              <?php else : ?>
                <div style="background:linear-gradient(135deg,#1e293b,#475569);position:absolute;inset:0;"></div>
              <?php endif; ?>
              <div class="hero-secondary__overlay"></div>
              <div class="hero-secondary__content">
                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                <div class="hero-secondary__meta"><?php dailyscroll_time_ago(); ?></div>
              </div>
            </div>
          <?php endif; ?>
        <?php endwhile; ?>
      </div>
    </section>
    <?php wp_reset_postdata(); endif; ?>

    <!-- Ad: After Hero -->
    <?php dailyscroll_ad('dailyscroll_ad_slot_header', 'leaderboard'); ?>

  <?php endif; ?>

  <!-- Main Content + Sidebar -->
  <div class="layout-main-sidebar">
    <div>

      <?php if (is_front_page() && !is_paged()) : ?>
        <div class="section-header">
          <div class="section-header__left">
            <div class="section-header__accent"></div>
            <span class="section-header__icon">📰</span>
            <h2 class="section-header__title">Latest Stories</h2>
          </div>
          <a href="<?php echo esc_url(home_url('/blog/')); ?>" class="section-header__link">
            All stories →
          </a>
        </div>
      <?php elseif (is_search()) : ?>
        <div class="archive-header">
          <h1>Search Results for: "<?php echo get_search_query(); ?>"</h1>
        </div>
      <?php elseif (is_archive()) : ?>
        <div class="archive-header">
          <h1><?php the_archive_title(); ?></h1>
        </div>
      <?php endif; ?>

      <?php if (have_posts()) : ?>
        <div class="grid-3">
          <?php
          $skip = (is_front_page() && !is_paged()) ? 4 : 0;
          $skipped = 0;
          while (have_posts()) : the_post();
            if ($skipped < $skip && is_front_page() && !is_paged()) { $skipped++; continue; }
          ?>
            <article class="card animate-fade-up" id="post-<?php the_ID(); ?>">
              <div class="card__img-wrap">
                <a href="<?php the_permalink(); ?>">
                  <?php if (has_post_thumbnail()) : ?>
                    <?php the_post_thumbnail('card-medium'); ?>
                  <?php else : ?>
                    <div style="width:100%;height:100%;background:linear-gradient(135deg,#e2e8f0,#cbd5e1);display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:13px;">No Image</div>
                  <?php endif; ?>
                </a>
              </div>
              <div class="card__body">
                <div class="card__category"><?php dailyscroll_category_badge(); ?></div>
                <h3 class="card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                <p class="card__excerpt"><?php echo get_the_excerpt(); ?></p>
                <div class="card__meta">
                  <span><?php the_author(); ?></span>
                  <span class="dot"></span>
                  <span><?php dailyscroll_time_ago(); ?></span>
                  <span class="dot"></span>
                  <span><?php dailyscroll_reading_time(); ?></span>
                </div>
              </div>
            </article>
          <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div class="pagination">
          <?php
          the_posts_pagination(array(
            'mid_size'  => 2,
            'prev_text' => '← Previous',
            'next_text' => 'Next →',
          ));
          ?>
        </div>

      <?php else : ?>
        <div style="text-align:center;padding:60px 0;">
          <div style="font-size:48px;margin-bottom:16px;">📭</div>
          <h2 style="font-size:20px;margin-bottom:8px;">No posts found</h2>
          <p style="color:var(--text-muted);">Try a different search or browse categories.</p>
        </div>
      <?php endif; ?>

    </div>

    <!-- Sidebar -->
    <aside>
      <?php get_sidebar(); ?>
    </aside>
  </div>

</div>

<?php get_footer(); ?>
