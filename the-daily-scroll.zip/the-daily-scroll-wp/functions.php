<?php
/**
 * The Daily Scroll – Theme Functions
 */

if (!defined('ABSPATH')) exit;

// ── Theme Setup ───────────────────────────────────────────────────────────────
function dailyscroll_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 64,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('automatic-feed-links');
    add_theme_support('responsive-embeds');
    add_theme_support('wp-block-styles');
    add_theme_support('editor-styles');
    add_theme_support('custom-background', array('default-color' => 'f8fafc'));

    // Image sizes
    add_image_size('hero-large', 1200, 675, true);
    add_image_size('card-medium', 600, 340, true);
    add_image_size('card-thumb', 300, 200, true);

    // Navigation menus
    register_nav_menus(array(
        'primary'     => __('Primary Navigation', 'daily-scroll'),
        'footer'      => __('Footer Navigation', 'daily-scroll'),
        'mobile'      => __('Mobile Navigation', 'daily-scroll'),
    ));
}
add_action('after_setup_theme', 'dailyscroll_setup');

// ── Enqueue Styles & Scripts ──────────────────────────────────────────────────
function dailyscroll_scripts() {
    // Google Fonts
    wp_enqueue_style('google-fonts',
        'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;0,9..40,800;1,9..40,400&family=Playfair+Display:wght@700;800;900&display=swap',
        array(), null
    );

    // Theme stylesheet
    wp_enqueue_style('dailyscroll-style', get_stylesheet_uri(), array(), '1.0.0');

    // Theme JavaScript
    wp_enqueue_script('dailyscroll-main', get_template_directory_uri() . '/js/main.js', array(), '1.0.0', true);

    // Comment reply
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'dailyscroll_scripts');

// ── Google AdSense Script ─────────────────────────────────────────────────────
function dailyscroll_adsense_head() {
    $client_id = get_theme_mod('dailyscroll_adsense_id', '');
    if (!empty($client_id)) {
        echo '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . esc_attr($client_id) . '" crossorigin="anonymous"></script>' . "\n";
    }
}
add_action('wp_head', 'dailyscroll_adsense_head');

// ── Widgets ───────────────────────────────────────────────────────────────────
function dailyscroll_widgets() {
    register_sidebar(array(
        'name'          => __('Sidebar', 'daily-scroll'),
        'id'            => 'sidebar-1',
        'before_widget' => '<div class="sidebar-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="sidebar-widget__header"><div class="sidebar-widget__accent"></div><h3 class="sidebar-widget__title">',
        'after_title'   => '</h3></div>',
    ));

    register_sidebar(array(
        'name'          => __('Footer Widget Area', 'daily-scroll'),
        'id'            => 'footer-1',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="footer-col__title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'dailyscroll_widgets');

// ── Customizer Settings ───────────────────────────────────────────────────────
function dailyscroll_customizer($wp_customize) {
    // AdSense section
    $wp_customize->add_section('dailyscroll_ads', array(
        'title'    => __('Google AdSense', 'daily-scroll'),
        'priority' => 120,
    ));

    $wp_customize->add_setting('dailyscroll_adsense_id', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('dailyscroll_adsense_id', array(
        'label'       => __('AdSense Client ID', 'daily-scroll'),
        'description' => __('Enter your AdSense publisher ID (e.g., ca-pub-XXXXXXXXXXXXXXXX)', 'daily-scroll'),
        'section'     => 'dailyscroll_ads',
        'type'        => 'text',
    ));

    $wp_customize->add_setting('dailyscroll_ad_slot_header', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('dailyscroll_ad_slot_header', array(
        'label'   => __('Header Ad Slot ID', 'daily-scroll'),
        'section' => 'dailyscroll_ads',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('dailyscroll_ad_slot_sidebar', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('dailyscroll_ad_slot_sidebar', array(
        'label'   => __('Sidebar Ad Slot ID', 'daily-scroll'),
        'section' => 'dailyscroll_ads',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('dailyscroll_ad_slot_article', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('dailyscroll_ad_slot_article', array(
        'label'   => __('In-Article Ad Slot ID', 'daily-scroll'),
        'section' => 'dailyscroll_ads',
        'type'    => 'text',
    ));

    // Breaking news
    $wp_customize->add_section('dailyscroll_breaking', array(
        'title'    => __('Breaking News', 'daily-scroll'),
        'priority' => 110,
    ));

    $wp_customize->add_setting('dailyscroll_breaking_enabled', array(
        'default'           => false,
        'sanitize_callback' => 'wp_validate_boolean',
    ));

    $wp_customize->add_control('dailyscroll_breaking_enabled', array(
        'label'   => __('Enable Breaking News Ticker', 'daily-scroll'),
        'section' => 'dailyscroll_breaking',
        'type'    => 'checkbox',
    ));

    $wp_customize->add_setting('dailyscroll_breaking_text', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('dailyscroll_breaking_text', array(
        'label'   => __('Breaking News Text', 'daily-scroll'),
        'section' => 'dailyscroll_breaking',
        'type'    => 'text',
    ));
}
add_action('customize_register', 'dailyscroll_customizer');

// ── Helper: Ad Placeholder ────────────────────────────────────────────────────
function dailyscroll_ad($slot_setting, $size = 'leaderboard') {
    $slot = get_theme_mod($slot_setting, '');
    $client = get_theme_mod('dailyscroll_adsense_id', '');

    if (!empty($slot) && !empty($client)) {
        echo '<div class="ad-placeholder ad-placeholder--' . esc_attr($size) . '">';
        echo '<ins class="adsbygoogle" style="display:block" data-ad-client="' . esc_attr($client) . '" data-ad-slot="' . esc_attr($slot) . '" data-ad-format="auto" data-full-width-responsive="true"></ins>';
        echo '<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
        echo '</div>';
    } else {
        echo '<div class="ad-placeholder ad-placeholder--' . esc_attr($size) . '"><span>Advertisement</span></div>';
    }
}

// ── Helper: Category Badge ────────────────────────────────────────────────────
function dailyscroll_category_badge($cat = null) {
    if (!$cat) {
        $cats = get_the_category();
        if (empty($cats)) return;
        $cat = $cats[0];
    }
    $slug = is_object($cat) ? $cat->slug : sanitize_title($cat);
    $name = is_object($cat) ? $cat->name : $cat;
    echo '<span class="category-badge category-badge--' . esc_attr($slug) . '">' . esc_html($name) . '</span>';
}

// ── Helper: Time Ago ──────────────────────────────────────────────────────────
function dailyscroll_time_ago() {
    echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago';
}

// ── Helper: Reading Time ──────────────────────────────────────────────────────
function dailyscroll_reading_time() {
    $content = get_post_field('post_content', get_the_ID());
    $words = str_word_count(strip_tags($content));
    $minutes = max(1, ceil($words / 200));
    echo $minutes . ' min read';
}

// ── Excerpt Length ────────────────────────────────────────────────────────────
function dailyscroll_excerpt_length($length) {
    return 25;
}
add_filter('excerpt_length', 'dailyscroll_excerpt_length');

function dailyscroll_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'dailyscroll_excerpt_more');

// ── Body Class ────────────────────────────────────────────────────────────────
function dailyscroll_body_class($classes) {
    if (is_front_page()) $classes[] = 'is-front-page';
    if (is_single()) $classes[] = 'is-single';
    return $classes;
}
add_filter('body_class', 'dailyscroll_body_class');
