<?php if (post_password_required()) return; ?>

<div id="comments" class="comments-area">
  <?php if (have_comments()) : ?>
    <h2><?php printf(_n('One Comment', '%s Comments', get_comments_number(), 'daily-scroll'), number_format_i18n(get_comments_number())); ?></h2>
    <ol class="comment-list" style="list-style:none;padding:0;">
      <?php
      wp_list_comments(array(
        'style'       => 'ol',
        'short_ping'  => true,
        'avatar_size' => 48,
      ));
      ?>
    </ol>
    <?php the_comments_navigation(); ?>
  <?php endif; ?>

  <?php comment_form(array(
    'class_form'    => 'comment-form',
    'title_reply'   => '<h3 style="font-size:20px;margin-bottom:16px;">Leave a Comment</h3>',
    'label_submit'  => 'Post Comment',
    'class_submit'  => 'submit',
  )); ?>
</div>
