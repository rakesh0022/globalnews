<?php get_header(); ?>

<div class="container">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

    <div class="page-header animate-fade-up">
      <div class="page-header__label">
        <div class="page-header__accent"></div>
        <span><?php
          // Show parent page name or "Page"
          $parent = wp_get_post_parent_id(get_the_ID());
          echo $parent ? get_the_title($parent) : 'Page';
        ?></span>
      </div>
      <h1><?php the_title(); ?></h1>
    </div>

    <div class="page-content">
      <?php the_content(); ?>
    </div>

  <?php endwhile; endif; ?>
</div>

<?php get_footer(); ?>
