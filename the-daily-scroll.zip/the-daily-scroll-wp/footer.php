</main>

<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-col">
        <div class="footer-col__title">News</div>
        <?php
        $cats = get_categories(array('number' => 6, 'hide_empty' => false));
        foreach ($cats as $cat) {
          echo '<a href="' . esc_url(get_category_link($cat->term_id)) . '">' . esc_html($cat->name) . '</a>';
        }
        ?>
      </div>
      <div class="footer-col">
        <div class="footer-col__title">Features</div>
        <a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a>
        <a href="<?php echo esc_url(home_url('/?s=trending')); ?>">Trending</a>
        <a href="#">Newsletter</a>
      </div>
      <div class="footer-col">
        <div class="footer-col__title">Company</div>
        <a href="<?php echo esc_url(home_url('/about/')); ?>">About Us</a>
        <a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a>
      </div>
      <div class="footer-col">
        <div class="footer-col__title">Legal</div>
        <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a>
        <a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>">Terms of Service</a>
        <a href="<?php echo esc_url(home_url('/disclaimer/')); ?>">Disclaimer</a>
        <a href="<?php echo esc_url(home_url('/dmca/')); ?>">DMCA</a>
      </div>
    </div>
    <div class="footer-bottom">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo" style="gap:8px;">
        <div class="logo-icon" style="width:28px;height:28px;border-radius:10px;">
          <svg xmlns="http://www.w3.org/2000/svg" style="width:14px;height:14px;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/></svg>
        </div>
        <span class="logo-text" style="font-size:16px;">Daily<span class="gradient-text">Scroll</span></span>
      </a>
      <span class="footer-bottom__copy">&copy; <?php echo date('Y'); ?> The Daily Scroll. All rights reserved.</span>
      <div class="footer-bottom__links">
        <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy</a>
        <a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>">Terms</a>
        <a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a>
      </div>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
