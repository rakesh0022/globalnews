<?php get_header(); ?>

<!-- Reading Progress Bar -->
<div class="reading-progress"><div class="reading-progress__bar" id="readingProgress"></div></div>

<div class="container">

  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

    <!-- Article Header -->
    <div class="article-header animate-fade-up">
      <div class="article-header__category"><?php dailyscroll_category_badge(); ?></div>
      <h1><?php the_title(); ?></h1>
      <?php if (has_excerpt()) : ?>
        <p class="article-header__excerpt"><?php echo get_the_excerpt(); ?></p>
      <?php endif; ?>
    </div>

    <!-- Byline -->
    <div class="article-byline">
      <div class="article-byline__author">
        <div class="article-byline__avatar"><?php echo strtoupper(substr(get_the_author(), 0, 1)); ?></div>
        <div>
          <div class="article-byline__name"><?php the_author(); ?></div>
          <div class="article-byline__date">
            <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date('F j, Y \a\t g:i A'); ?></time>
            · <?php dailyscroll_reading_time(); ?>
          </div>
        </div>
      </div>
      <div class="share-buttons">
        <a class="share-btn" href="https://twitter.com/intent/tweet?text=<?php echo urlencode(get_the_title()); ?>&url=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="noopener" title="Share on X">
          <svg fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
        </a>
        <a class="share-btn" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="noopener" title="Share on Facebook">
          <svg fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
        </a>
        <button class="share-btn" onclick="navigator.clipboard.writeText(window.location.href);this.title='Copied!'" title="Copy link">
          <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
        </button>
      </div>
    </div>

    <!-- Featured Image -->
    <?php if (has_post_thumbnail()) : ?>
      <div class="article-featured-img">
        <?php the_post_thumbnail('hero-large'); ?>
      </div>
    <?php endif; ?>

    <!-- Article Body + Sidebar -->
    <div class="layout-main-sidebar">
      <div>
        <div class="article-body">
          <?php the_content(); ?>
        </div>

        <!-- Ad: After Article -->
        <?php dailyscroll_ad('dailyscroll_ad_slot_article', 'in-article'); ?>

        <!-- Tags -->
        <?php if (has_tag()) : ?>
          <div style="max-width:780px;margin:32px auto 0;">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
              <span style="font-size:12px;font-weight:700;color:var(--text-light);text-transform:uppercase;letter-spacing:0.05em;">Tags:</span>
              <?php the_tags('', ' ', ''); ?>
            </div>
          </div>
        <?php endif; ?>

        <!-- Comments -->
        <div class="comments-area">
          <?php if (comments_open() || get_comments_number()) : comments_template(); endif; ?>
        </div>
      </div>

      <!-- Sidebar -->
      <aside>
        <?php get_sidebar(); ?>
      </aside>
    </div>

    <!-- Related Posts -->
    <?php
    $cats = get_the_category();
    if (!empty($cats)) :
      $related = new WP_Query(array(
        'category__in'   => array($cats[0]->term_id),
        'post__not_in'   => array(get_the_ID()),
        'posts_per_page' => 4,
        'orderby'        => 'rand',
      ));
      if ($related->have_posts()) :
    ?>
    <section style="margin-top:64px;padding-top:40px;border-top:1px solid var(--border);">
      <div class="section-header">
        <div class="section-header__left">
          <div class="section-header__accent"></div>
          <h2 class="section-header__title">Related Articles</h2>
        </div>
      </div>
      <div class="grid-4">
        <?php while ($related->have_posts()) : $related->the_post(); ?>
          <article class="card">
            <div class="card__img-wrap">
              <a href="<?php the_permalink(); ?>">
                <?php if (has_post_thumbnail()) : the_post_thumbnail('card-medium'); else : ?>
                  <div style="width:100%;height:100%;background:linear-gradient(135deg,#e2e8f0,#cbd5e1);"></div>
                <?php endif; ?>
              </a>
            </div>
            <div class="card__body">
              <div class="card__category"><?php dailyscroll_category_badge(); ?></div>
              <h3 class="card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
              <div class="card__meta">
                <span><?php dailyscroll_time_ago(); ?></span>
                <span class="dot"></span>
                <span><?php dailyscroll_reading_time(); ?></span>
              </div>
            </div>
          </article>
        <?php endwhile; ?>
      </div>
    </section>
    <?php wp_reset_postdata(); endif; endif; ?>

  <?php endwhile; endif; ?>
</div>

<?php get_footer(); ?>
