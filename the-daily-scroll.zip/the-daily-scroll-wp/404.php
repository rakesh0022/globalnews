<?php get_header(); ?>
<div class="container" style="text-align:center;padding:80px 0;">
  <div style="font-size:80px;margin-bottom:20px;">🔮</div>
  <h1 style="font-size:48px;font-weight:800;margin-bottom:12px;">404</h1>
  <p style="font-size:18px;color:var(--text-muted);margin-bottom:32px;max-width:400px;margin-left:auto;margin-right:auto;">
    The page you're looking for doesn't exist or has been moved.
  </p>
  <a href="<?php echo esc_url(home_url('/')); ?>"
     style="display:inline-flex;align-items:center;gap:8px;padding:14px 28px;background:var(--accent-gradient);color:#fff;font-weight:700;font-size:15px;border-radius:var(--radius-sm);box-shadow:0 4px 12px rgba(37,99,235,0.3);transition:all 0.2s;">
    ← Back to Homepage
  </a>
</div>
<?php get_footer(); ?>
