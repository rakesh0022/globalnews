<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
  <script>
    // Prevent flash — apply dark mode before paint
    (function(){
      var d = localStorage.getItem('ds_dark_mode');
      if (d === '1' || (!d && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark-mode');
      }
    })();
  </script>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Search Overlay -->
<div class="search-overlay" id="searchOverlay">
  <button class="search-overlay__close" id="searchClose">&times;</button>
  <div class="search-overlay__inner">
    <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
      <input type="text" class="search-overlay__input" name="s" placeholder="Search articles..." value="<?php echo get_search_query(); ?>" autofocus>
    </form>
  </div>
</div>

<!-- Mobile Menu -->
<div class="mobile-menu" id="mobileMenu">
  <div class="mobile-menu__overlay" id="mobileOverlay"></div>
  <div class="mobile-menu__panel">
    <button class="mobile-menu__close" id="mobileClose">&times;</button>
    <?php
    wp_nav_menu(array(
      'theme_location' => 'mobile',
      'container'      => false,
      'fallback_cb'    => 'dailyscroll_fallback_menu',
    ));
    ?>
  </div>
</div>

<!-- Header -->
<header class="site-header" id="siteHeader">
  <div class="container">
    <div class="nav-inner">

      <!-- Logo -->
      <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
        <div class="logo-icon">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
          </svg>
        </div>
        <span class="logo-text">Daily<span class="gradient-text">Scroll</span></span>
      </a>

      <!-- Desktop Nav -->
      <nav class="nav-links">
        <?php
        wp_nav_menu(array(
          'theme_location' => 'primary',
          'container'      => false,
          'items_wrap'     => '%3$s',
          'fallback_cb'    => 'dailyscroll_fallback_menu_items',
        ));
        ?>
      </nav>

      <!-- Actions -->
      <div class="nav-actions">
        <button class="search-toggle" id="searchToggle" aria-label="Search">
          <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        </button>
        <button class="theme-toggle" id="themeToggle" aria-label="Toggle dark mode">
          <svg class="sun-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
          <svg class="moon-icon" style="display:none;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
        </button>
        <button class="menu-toggle" id="menuToggle" aria-label="Open menu">
          <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
      </div>

    </div>
  </div>
</header>

<?php
// Breaking News Ticker
if (get_theme_mod('dailyscroll_breaking_enabled', false)) :
  $breaking_text = get_theme_mod('dailyscroll_breaking_text', '');
  if (!empty($breaking_text)) :
?>
<div class="breaking-ticker">
  <div class="breaking-ticker__inner">
    <div class="breaking-ticker__label">
      <span class="pulse"></span>
      <span>Breaking</span>
    </div>
    <div class="breaking-ticker__track">
      <div class="breaking-ticker__scroll">
        <a href="#"><?php echo esc_html($breaking_text); ?></a>
        <a href="#"><?php echo esc_html($breaking_text); ?></a>
      </div>
    </div>
  </div>
</div>
<?php endif; endif; ?>

<main>
<?php
// Fallback menu functions
function dailyscroll_fallback_menu() {
    echo '<a href="' . esc_url(home_url('/')) . '">Home</a>';
    wp_list_categories(array('title_li' => '', 'style' => 'none', 'separator' => ''));
}

function dailyscroll_fallback_menu_items() {
    echo '<a href="' . esc_url(home_url('/')) . '">Home</a>';
    $cats = get_categories(array('number' => 6, 'hide_empty' => false));
    foreach ($cats as $cat) {
        echo '<a href="' . esc_url(get_category_link($cat->term_id)) . '">' . esc_html($cat->name) . '</a>';
    }
    echo '<a href="' . esc_url(home_url('/blog/')) . '">Blog</a>';
}
