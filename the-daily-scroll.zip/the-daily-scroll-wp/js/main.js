/**
 * The Daily Scroll — Theme JavaScript
 */
document.addEventListener('DOMContentLoaded', function() {

  // ── Dark Mode Toggle ────────────────────────────────────────────────────
  var toggle = document.getElementById('themeToggle');
  var sunIcon = toggle ? toggle.querySelector('.sun-icon') : null;
  var moonIcon = toggle ? toggle.querySelector('.moon-icon') : null;

  function updateIcons() {
    var isDark = document.documentElement.classList.contains('dark-mode');
    if (sunIcon) sunIcon.style.display = isDark ? 'none' : 'block';
    if (moonIcon) moonIcon.style.display = isDark ? 'block' : 'none';
  }

  updateIcons();

  if (toggle) {
    toggle.addEventListener('click', function() {
      document.documentElement.classList.toggle('dark-mode');
      var isDark = document.documentElement.classList.contains('dark-mode');
      localStorage.setItem('ds_dark_mode', isDark ? '1' : '0');
      updateIcons();
    });
  }

  // ── Mobile Menu ─────────────────────────────────────────────────────────
  var menuToggle = document.getElementById('menuToggle');
  var mobileMenu = document.getElementById('mobileMenu');
  var mobileOverlay = document.getElementById('mobileOverlay');
  var mobileClose = document.getElementById('mobileClose');

  function openMenu() {
    if (mobileMenu) mobileMenu.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
  function closeMenu() {
    if (mobileMenu) mobileMenu.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (menuToggle) menuToggle.addEventListener('click', openMenu);
  if (mobileOverlay) mobileOverlay.addEventListener('click', closeMenu);
  if (mobileClose) mobileClose.addEventListener('click', closeMenu);

  // ── Search Overlay ──────────────────────────────────────────────────────
  var searchToggle = document.getElementById('searchToggle');
  var searchOverlay = document.getElementById('searchOverlay');
  var searchClose = document.getElementById('searchClose');
  var searchInput = searchOverlay ? searchOverlay.querySelector('input') : null;

  function openSearch() {
    if (searchOverlay) searchOverlay.classList.add('active');
    if (searchInput) searchInput.focus();
    document.body.style.overflow = 'hidden';
  }
  function closeSearch() {
    if (searchOverlay) searchOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (searchToggle) searchToggle.addEventListener('click', openSearch);
  if (searchClose) searchClose.addEventListener('click', closeSearch);
  if (searchOverlay) {
    searchOverlay.addEventListener('click', function(e) {
      if (e.target === searchOverlay) closeSearch();
    });
  }

  // Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') { closeSearch(); closeMenu(); }
  });

  // ── Sticky Header Shadow ────────────────────────────────────────────────
  var header = document.getElementById('siteHeader');
  window.addEventListener('scroll', function() {
    if (header) {
      if (window.scrollY > 10) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }
  }, { passive: true });

  // ── Reading Progress Bar ────────────────────────────────────────────────
  var progressBar = document.getElementById('readingProgress');
  if (progressBar) {
    window.addEventListener('scroll', function() {
      var scrollTop = window.scrollY;
      var docHeight = document.documentElement.scrollHeight - window.innerHeight;
      var progress = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
      progressBar.style.width = progress + '%';
    }, { passive: true });
  }

  // ── Fade-up animation on scroll ─────────────────────────────────────────
  var fadeEls = document.querySelectorAll('.animate-fade-up');
  if ('IntersectionObserver' in window && fadeEls.length) {
    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    fadeEls.forEach(function(el) {
      el.style.opacity = '0';
      el.style.transform = 'translateY(16px)';
      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      observer.observe(el);
    });
  }

  console.log('The Daily Scroll loaded.');
});
