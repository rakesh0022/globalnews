<?php
// archive.php — Category, tag, date, author archives
// Falls through to index.php which handles all listing layouts
get_header();
?>
<div class="container">
  <div class="archive-header animate-fade-up" style="padding:40px 0 24px;">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
      <div style="width:4px;height:28px;border-radius:4px;background:var(--accent-gradient);"></div>
      <span style="font-size:12px;font-weight:800;color:var(--accent);text-transform:uppercase;letter-spacing:0.1em;">
        <?php
        if (is_category()) echo 'Category';
        elseif (is_tag()) echo 'Tag';
        elseif (is_author()) echo 'Author';
        elseif (is_date()) echo 'Archive';
        else echo 'Archive';
        ?>
      </span>
    </div>
    <h1 style="font-size:36px;font-weight:800;letter-spacing:-0.02em;"><?php the_archive_title(); ?></h1>
    <?php if (category_description()) : ?>
      <p style="font-size:17px;color:var(--text-muted);margin-top:8px;"><?php echo category_description(); ?></p>
    <?php endif; ?>
  </div>

  <!-- Ad: Top of archive -->
  <?php dailyscroll_ad('dailyscroll_ad_slot_header', 'leaderboard'); ?>

  <div class="layout-main-sidebar">
    <div>
      <?php if (have_posts()) : ?>
        <div class="grid-3">
          <?php while (have_posts()) : the_post(); ?>
            <article class="card animate-fade-up">
              <div class="card__img-wrap">
                <a href="<?php the_permalink(); ?>">
                  <?php if (has_post_thumbnail()) : the_post_thumbnail('card-medium'); else : ?>
                    <div style="width:100%;height:100%;background:linear-gradient(135deg,#e2e8f0,#cbd5e1);display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:13px;">No Image</div>
                  <?php endif; ?>
                </a>
              </div>
              <div class="card__body">
                <div class="card__category"><?php dailyscroll_category_badge(); ?></div>
                <h3 class="card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                <p class="card__excerpt"><?php echo get_the_excerpt(); ?></p>
                <div class="card__meta">
                  <span><?php the_author(); ?></span>
                  <span class="dot"></span>
                  <span><?php dailyscroll_time_ago(); ?></span>
                </div>
              </div>
            </article>
          <?php endwhile; ?>
        </div>
        <div class="pagination">
          <?php the_posts_pagination(array('mid_size' => 2, 'prev_text' => '← Previous', 'next_text' => 'Next →')); ?>
        </div>
      <?php else : ?>
        <div style="text-align:center;padding:60px 0;">
          <div style="font-size:48px;margin-bottom:16px;">📭</div>
          <h2>No posts found in this category</h2>
        </div>
      <?php endif; ?>
    </div>
    <aside><?php get_sidebar(); ?></aside>
  </div>
</div>
<?php get_footer(); ?>
