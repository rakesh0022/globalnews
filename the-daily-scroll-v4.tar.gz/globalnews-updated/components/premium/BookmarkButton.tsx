"use client";

import { useState, useEffect } from "react";
import { Article } from "@/types";

const BOOKMARKS_KEY = "dailyscroll_bookmarks";

function getBookmarks(): Article[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]"); }
  catch { return []; }
}

function saveBookmarks(bookmarks: Article[]) {
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(bookmarks));
}

interface Props {
  article: Article;
  size?: "sm" | "md";
  className?: string;
}

export default function BookmarkButton({ article, size = "sm", className = "" }: Props) {
  const [saved, setSaved] = useState(false);
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    const bookmarks = getBookmarks();
    setSaved(bookmarks.some((b) => b.id === article.id));
  }, [article.id]);

  function toggle(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    const bookmarks = getBookmarks();
    if (saved) {
      saveBookmarks(bookmarks.filter((b) => b.id !== article.id));
      setSaved(false);
    } else {
      saveBookmarks([article, ...bookmarks]);
      setSaved(true);
      setAnimate(true);
      setTimeout(() => setAnimate(false), 600);
    }
  }

  const iconSize = size === "md" ? "w-5 h-5" : "w-4 h-4";
  const btnSize = size === "md" ? "w-9 h-9" : "w-7 h-7";

  return (
    <button onClick={toggle} title={saved ? "Remove bookmark" : "Save for later"}
      className={`${btnSize} rounded-full flex items-center justify-center transition-all ${
        saved
          ? "bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400"
          : "bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/20"
      } ${animate ? "scale-125" : "scale-100"} ${className}`}>
      <svg className={iconSize} fill={saved ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
      </svg>
    </button>
  );
}
