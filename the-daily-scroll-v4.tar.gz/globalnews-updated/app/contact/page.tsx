"use client";

import { useState } from "react";
import { Metadata } from "next";

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (form.name && form.email && form.message) setSubmitted(true);
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
      <div className="space-y-3 mb-10 animate-fade-up">
        <div className="flex items-center gap-2">
          <div className="w-1 h-7 rounded-full bg-gradient-to-b from-blue-500 to-violet-600" />
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">Get in Touch</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">Contact Us</h1>
        <p className="text-lg text-slate-500 dark:text-slate-400">Have a question, news tip, or feedback? We&apos;d love to hear from you.</p>
      </div>

      {submitted ? (
        <div className="rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 p-8 text-center space-y-3">
          <div className="text-4xl">✅</div>
          <h2 className="text-xl font-bold text-emerald-800 dark:text-emerald-200">Message Sent!</h2>
          <p className="text-emerald-600 dark:text-emerald-400">Thank you for reaching out. We&apos;ll get back to you within 24–48 hours.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
          <div className="lg:col-span-3">
            <div className="rounded-2xl bg-white dark:bg-[#0d1526] border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
              <div className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Name *</label>
                    <input type="text" value={form.name} onChange={(e) => setForm({...form, name: e.target.value})}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0a1020] text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition" placeholder="Your name" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Email *</label>
                    <input type="email" value={form.email} onChange={(e) => setForm({...form, email: e.target.value})}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0a1020] text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition" placeholder="you@example.com" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Subject</label>
                  <select value={form.subject} onChange={(e) => setForm({...form, subject: e.target.value})}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0a1020] text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
                    <option value="">Select a topic</option>
                    <option value="general">General Inquiry</option>
                    <option value="feedback">Feedback</option>
                    <option value="news-tip">News Tip</option>
                    <option value="advertising">Advertising</option>
                    <option value="bug">Report a Bug</option>
                    <option value="partnership">Partnership</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Message *</label>
                  <textarea rows={5} value={form.message} onChange={(e) => setForm({...form, message: e.target.value})}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0a1020] text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition resize-none" placeholder="Your message..." />
                </div>
                <button onClick={handleSubmit}
                  className="w-full sm:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 text-white font-semibold shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all hover:-translate-y-0.5">
                  Send Message
                </button>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-5">
            {[
              { icon: "📧", label: "Email", value: "hello@surajpandey.in", href: "mailto:hello@surajpandey.in" },
              { icon: "🐦", label: "Twitter / X", value: "@newshub", href: "#" },
              { icon: "💼", label: "Advertising", value: "ads@surajpandey.in", href: "mailto:ads@surajpandey.in" },
              { icon: "📰", label: "Press", value: "press@surajpandey.in", href: "mailto:press@surajpandey.in" },
            ].map((item) => (
              <a key={item.label} href={item.href}
                className="flex items-center gap-4 p-4 rounded-2xl bg-white dark:bg-[#0d1526] border border-slate-200 dark:border-slate-800 hover:shadow-md transition-shadow">
                <span className="text-2xl">{item.icon}</span>
                <div>
                  <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">{item.label}</div>
                  <div className="text-sm font-bold text-slate-900 dark:text-white">{item.value}</div>
                </div>
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
