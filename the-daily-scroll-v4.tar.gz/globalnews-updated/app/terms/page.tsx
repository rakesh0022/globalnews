import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "The Daily Scroll Terms of Service — the rules and guidelines for using our platform.",
};

export default function TermsPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
      <div className="space-y-3 mb-10 animate-fade-up">
        <div className="flex items-center gap-2">
          <div className="w-1 h-7 rounded-full bg-gradient-to-b from-blue-500 to-violet-600" />
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">Legal</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">Terms of Service</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Last updated: April 14, 2026</p>
      </div>

      <article className="prose prose-slate dark:prose-invert max-w-none prose-headings:tracking-tight">
        <p>Welcome to The Daily Scroll. By accessing or using our website, you agree to be bound by these Terms of Service.</p>

        <h2>1. Acceptance of Terms</h2>
        <p>By using The Daily Scroll, you acknowledge that you have read, understood, and agree to these Terms. If you do not agree, please discontinue use of the website.</p>

        <h2>2. Use of Service</h2>
        <p>You agree to use The Daily Scroll only for lawful purposes and in accordance with these Terms. You agree not to:</p>
        <ul>
          <li>Use the service for any illegal or unauthorized purpose</li>
          <li>Attempt to interfere with or disrupt the service</li>
          <li>Scrape, crawl, or extract data without permission</li>
          <li>Distribute malware or harmful code</li>
          <li>Impersonate any person or entity</li>
          <li>Violate any applicable laws or regulations</li>
        </ul>

        <h2>3. Intellectual Property</h2>
        <p>All content on The Daily Scroll, including articles, graphics, logos, and software, is protected by copyright and other intellectual property laws. Content sourced from third-party news providers belongs to their respective owners. You may not reproduce, distribute, or create derivative works without permission.</p>

        <h2>4. User Content</h2>
        <p>If you submit comments, feedback, or other content, you grant The Daily Scroll a non-exclusive, royalty-free license to use, display, and distribute that content in connection with our services.</p>

        <h2>5. Third-Party Content and Links</h2>
        <p>The Daily Scroll may contain links to third-party websites and content from external news sources. We are not responsible for the content, accuracy, or practices of third-party sites.</p>

        <h2>6. Advertising</h2>
        <p>Our service may display advertisements provided by third-party ad networks including Google AdSense. Your interaction with advertisements is governed by the advertiser&apos;s own terms and policies.</p>

        <h2>7. Disclaimer of Warranties</h2>
        <p>The Daily Scroll is provided &quot;as is&quot; without warranties of any kind, express or implied. We do not guarantee the accuracy, completeness, or timeliness of any content. News articles are sourced from third-party providers and may contain errors.</p>

        <h2>8. Limitation of Liability</h2>
        <p>The Daily Scroll shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of the service.</p>

        <h2>9. Modifications</h2>
        <p>We reserve the right to modify these Terms at any time. Continued use after changes constitutes acceptance of the new Terms.</p>

        <h2>10. Governing Law</h2>
        <p>These Terms shall be governed by and construed in accordance with applicable laws, without regard to conflict of law principles.</p>

        <h2>11. Contact</h2>
        <p>For questions about these Terms, contact us at <a href="mailto:legal@surajpandey.in">legal@surajpandey.in</a>.</p>
      </article>
    </div>
  );
}
