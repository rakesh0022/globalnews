import { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "About Us",
  description: "Learn about The Daily Scroll — your go-to source for social media facts, trending stories, and thoughtful news coverage by Suraj Pandey.",
};

export default function AboutPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
      <div className="space-y-3 mb-10 animate-fade-up">
        <div className="flex items-center gap-2">
          <div className="w-1 h-7 rounded-full bg-gradient-to-b from-blue-500 to-violet-600" />
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">About</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">About The Daily Scroll</h1>
      </div>

      <article className="prose prose-slate dark:prose-invert max-w-none prose-lg prose-headings:tracking-tight prose-a:text-blue-600 dark:prose-a:text-blue-400">
        <p>
          <strong>The Daily Scroll</strong> is a modern digital platform created by <strong>Suraj Pandey</strong> — built for people who love scrolling through interesting facts, trending stories, and real news that matters.
        </p>

        <h2>What We Do</h2>
        <p>
          We take the best of social media — the quick, shareable, fascinating facts you see on Facebook and Instagram — and give them a proper home. Every fact we post on our social media pages gets a detailed blog and article treatment here, with sources, context, and deeper analysis.
        </p>

        <h2>Why The Daily Scroll?</h2>
        <p>
          Social media feeds move fast. A great fact post gets buried in hours. The Daily Scroll is where those stories live permanently — organized, searchable, and beautifully presented. Think of it as your personal archive of everything interesting you&apos;ve scrolled past.
        </p>

        <h2>What You&apos;ll Find Here</h2>
        <ul>
          <li><strong>Facts &amp; Trivia</strong> — Fascinating facts we share on our social media, with full sourcing and context</li>
          <li><strong>Trending News</strong> — Coverage of what&apos;s happening in tech, science, business, sports, health, and entertainment</li>
          <li><strong>In-Depth Blog Posts</strong> — Deep dives into topics our audience cares about</li>
          <li><strong>Personalized Feed</strong> — The site learns your interests and surfaces stories that matter to you</li>
          <li><strong>Bookmarks</strong> — Save articles to read later, no account needed</li>
        </ul>

        <h2>Follow Us</h2>
        <p>
          We&apos;re most active on Facebook and Instagram where we post daily facts and stories. Follow us there for quick bites, then come here for the full story.
        </p>

        <h2>Contact</h2>
        <p>
          Have a fact to share, a correction, or just want to say hi? Visit our <Link href="/contact">Contact page</Link> or email us at <a href="mailto:hello@surajpandey.in">hello@surajpandey.in</a>.
        </p>
      </article>
    </div>
  );
}
