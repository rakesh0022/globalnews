import type { Metadata, Viewport } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import BottomNav from "@/components/layout/BottomNav";
import PreferencesProvider from "@/components/providers/PreferencesProvider";
import ThemeProvider from "@/components/providers/ThemeProvider";
import PageWrapper from "@/components/motion/PageWrapper";

const geist = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
  preload: true,
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f9fafb" },
    { media: "(prefers-color-scheme: dark)", color: "#030712" },
  ],
};

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_BASE_URL ?? "http://localhost:3000"
  ),
  title: {
    default: "The Daily Scroll — Facts Worth Sharing",
    template: "%s | The Daily Scroll",
  },
  description:
    "Your daily scroll of facts worth sharing. Trending news, fascinating facts, and in-depth stories on tech, science, business, health, and more.",
  keywords: ["news", "facts", "social media", "trending", "technology", "sports", "business", "health", "science"],
  authors: [{ name: "The Daily Scroll" }],
  creator: "The Daily Scroll",
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  openGraph: {
    title: "The Daily Scroll — Facts Worth Sharing",
    description: "Your daily scroll of facts worth sharing.",
    type: "website",
    locale: "en_US",
    siteName: "The Daily Scroll",
  },
  twitter: {
    card: "summary_large_image",
    title: "The Daily Scroll — Facts Worth Sharing",
    description: "Your daily scroll of facts worth sharing.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      className={`${geist.variable} h-full antialiased`}
      suppressHydrationWarning
    >
      <head>
        {/* Google AdSense — replace ca-pub-XXXXXXXXXXXXXXXX with your client ID */}
        {process.env.NEXT_PUBLIC_ADSENSE_CLIENT_ID && (
          <script
            async
            src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${process.env.NEXT_PUBLIC_ADSENSE_CLIENT_ID}`}
            crossOrigin="anonymous"
          />
        )}
      </head>
      <body className="min-h-full flex flex-col bg-[#f8fafc] dark:bg-[#060b14] text-slate-900 dark:text-slate-100">
        <ThemeProvider>
          <Navbar />

          <main className="flex-1">
            <PreferencesProvider>
              <PageWrapper>{children}</PageWrapper>
            </PreferencesProvider>
          </main>

          <div className="hidden sm:block">
            <Footer />
          </div>

          <BottomNav />
        </ThemeProvider>
      </body>
    </html>
  );
}
