import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "The Daily Scroll Privacy Policy — how we collect, use, and protect your data.",
};

export default function PrivacyPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
      <div className="space-y-3 mb-10 animate-fade-up">
        <div className="flex items-center gap-2">
          <div className="w-1 h-7 rounded-full bg-gradient-to-b from-blue-500 to-violet-600" />
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">Legal</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">Privacy Policy</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Last updated: April 14, 2026</p>
      </div>

      <article className="prose prose-slate dark:prose-invert max-w-none prose-headings:tracking-tight">
        <p>The Daily Scroll (&quot;we&quot;, &quot;us&quot;, or &quot;our&quot;) is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website.</p>

        <h2>Information We Collect</h2>
        <h3>Information You Provide</h3>
        <p>We may collect information you voluntarily provide, including:</p>
        <ul>
          <li>Email address (when subscribing to our newsletter)</li>
          <li>Contact information (when using our contact form)</li>
          <li>Comments and feedback you submit</li>
        </ul>

        <h3>Automatically Collected Information</h3>
        <p>When you visit our website, we may automatically collect:</p>
        <ul>
          <li>Browser type and version</li>
          <li>Operating system</li>
          <li>Pages visited and time spent</li>
          <li>Referring website addresses</li>
          <li>IP address (anonymized)</li>
          <li>Device identifiers</li>
        </ul>

        <h3>Cookies and Tracking Technologies</h3>
        <p>We use cookies and similar technologies to:</p>
        <ul>
          <li>Remember your preferences (e.g., dark mode, reading interests)</li>
          <li>Analyze site traffic and usage patterns</li>
          <li>Deliver personalized content and recommendations</li>
          <li>Serve relevant advertisements through third-party ad networks</li>
        </ul>

        <h2>Third-Party Advertising</h2>
        <p>We use Google AdSense and other third-party advertising services to display ads on our website. These services may use cookies and similar technologies to serve ads based on your prior visits to our website and other websites. Google&apos;s use of advertising cookies enables it and its partners to serve ads based on your visit to our site and/or other sites on the Internet.</p>
        <p>You may opt out of personalized advertising by visiting <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer">Google Ads Settings</a> or <a href="https://optout.aboutads.info/" target="_blank" rel="noopener noreferrer">www.aboutads.info</a>.</p>

        <h2>How We Use Your Information</h2>
        <ul>
          <li>To deliver and improve our news services</li>
          <li>To personalize your content experience</li>
          <li>To send newsletters you&apos;ve subscribed to</li>
          <li>To analyze usage and optimize performance</li>
          <li>To display relevant advertisements</li>
          <li>To comply with legal obligations</li>
        </ul>

        <h2>Data Sharing</h2>
        <p>We do not sell your personal information. We may share data with:</p>
        <ul>
          <li>Analytics providers (e.g., Google Analytics)</li>
          <li>Advertising networks (e.g., Google AdSense)</li>
          <li>Service providers who assist our operations</li>
          <li>Law enforcement when required by law</li>
        </ul>

        <h2>Data Security</h2>
        <p>We implement appropriate technical and organizational measures to protect your information. However, no method of transmission over the Internet is 100% secure.</p>

        <h2>Your Rights</h2>
        <p>Depending on your jurisdiction, you may have the right to:</p>
        <ul>
          <li>Access your personal data</li>
          <li>Request correction or deletion of your data</li>
          <li>Object to or restrict data processing</li>
          <li>Data portability</li>
          <li>Withdraw consent</li>
        </ul>

        <h2>Children&apos;s Privacy</h2>
        <p>Our website is not intended for children under 13. We do not knowingly collect data from children under 13.</p>

        <h2>Changes to This Policy</h2>
        <p>We may update this Privacy Policy periodically. We will notify you of any changes by posting the new policy on this page and updating the &quot;Last updated&quot; date.</p>

        <h2>Contact Us</h2>
        <p>If you have questions about this Privacy Policy, please contact us at <a href="mailto:privacy@surajpandey.in">privacy@surajpandey.in</a>.</p>
      </article>
    </div>
  );
}
