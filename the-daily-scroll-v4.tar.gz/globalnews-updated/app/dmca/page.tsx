import { Metadata } from "next";

export const metadata: Metadata = {
  title: "DMCA Policy",
  description: "The Daily Scroll DMCA Takedown Policy — how to report copyright infringement.",
};

export default function DMCAPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
      <div className="space-y-3 mb-10 animate-fade-up">
        <div className="flex items-center gap-2">
          <div className="w-1 h-7 rounded-full bg-gradient-to-b from-blue-500 to-violet-600" />
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">Legal</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">DMCA Policy</h1>
      </div>
      <article className="prose prose-slate dark:prose-invert max-w-none prose-headings:tracking-tight">
        <p>The Daily Scroll respects the intellectual property rights of others and expects our users to do the same. In accordance with the Digital Millennium Copyright Act (DMCA), we will respond promptly to claims of copyright infringement.</p>
        <h2>Filing a DMCA Takedown Notice</h2>
        <p>If you believe that content on The Daily Scroll infringes your copyright, please send a written notice including:</p>
        <ol>
          <li>A physical or electronic signature of the copyright owner or authorized agent</li>
          <li>Identification of the copyrighted work claimed to have been infringed</li>
          <li>Identification of the material that is claimed to be infringing, with enough detail to locate it</li>
          <li>Your contact information (address, phone number, email)</li>
          <li>A statement that you have a good faith belief that the use is not authorized</li>
          <li>A statement, under penalty of perjury, that the information in the notice is accurate</li>
        </ol>
        <h2>Send Notices To</h2>
        <p>Email: <a href="mailto:dmca@surajpandey.in">dmca@surajpandey.in</a></p>
        <h2>Counter-Notification</h2>
        <p>If you believe your content was removed in error, you may file a counter-notification containing the information required under DMCA Section 512(g)(3).</p>
        <h2>Repeat Infringers</h2>
        <p>The Daily Scroll will terminate accounts of users who are repeat copyright infringers in appropriate circumstances.</p>
      </article>
    </div>
  );
}
