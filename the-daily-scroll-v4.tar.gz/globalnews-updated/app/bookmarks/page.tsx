"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { Article } from "@/types";
import { formatDate } from "@/lib/utils";
import CategoryBadge from "@/components/ui/CategoryBadge";
import NewsCard from "@/components/news/NewsCard";

const BOOKMARKS_KEY = "dailyscroll_bookmarks";

function getBookmarks(): Article[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
  } catch { return []; }
}

export default function BookmarksPage() {
  const [bookmarks, setBookmarks] = useState<Article[]>([]);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setBookmarks(getBookmarks());
    setMounted(true);
  }, []);

  function removeBookmark(id: string) {
    const updated = bookmarks.filter((b) => b.id !== id);
    setBookmarks(updated);
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(updated));
  }

  function clearAll() {
    setBookmarks([]);
    localStorage.setItem(BOOKMARKS_KEY, "[]");
  }

  if (!mounted) return null;

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-14">
      <div className="mb-10 space-y-3 animate-fade-up">
        <div className="flex items-center gap-2">
          <div className="w-1 h-7 rounded-full bg-gradient-to-b from-amber-400 to-orange-500" />
          <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest">Your Library</span>
        </div>
        <div className="flex items-center justify-between">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">Bookmarks</h1>
          {bookmarks.length > 0 && (
            <button onClick={clearAll}
              className="text-xs font-semibold text-red-500 hover:text-red-600 bg-red-50 dark:bg-red-950/30 px-3 py-1.5 rounded-full transition-colors">
              Clear All
            </button>
          )}
        </div>
        <p className="text-lg text-slate-500 dark:text-slate-400">
          {bookmarks.length > 0 ? `${bookmarks.length} saved article${bookmarks.length > 1 ? "s" : ""}` : "Articles you save will appear here."}
        </p>
      </div>

      {bookmarks.length === 0 ? (
        <div className="text-center py-20 space-y-4">
          <div className="text-6xl">🔖</div>
          <h2 className="text-xl font-bold text-slate-700 dark:text-slate-300">No bookmarks yet</h2>
          <p className="text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            Tap the bookmark icon on any article to save it for later reading.
          </p>
          <Link href="/"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 text-white font-semibold shadow-lg hover:-translate-y-0.5 transition-all">
            Browse News
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {bookmarks.map((article) => (
            <div key={article.id} className="relative group">
              <NewsCard article={article} />
              <button onClick={() => removeBookmark(article.id)}
                className="absolute top-3 right-3 w-8 h-8 rounded-full bg-red-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg z-10"
                title="Remove bookmark">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
