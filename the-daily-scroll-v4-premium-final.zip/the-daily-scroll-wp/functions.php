<?php
if(!defined('ABSPATH'))exit;
function ds_setup(){
  add_theme_support('title-tag');add_theme_support('post-thumbnails');
  add_theme_support('custom-logo',['height'=>64,'width'=>200,'flex-height'=>true,'flex-width'=>true]);
  add_theme_support('html5',['search-form','comment-form','comment-list','gallery','caption']);
  add_theme_support('automatic-feed-links');add_theme_support('responsive-embeds');
  add_image_size('hero-lg',1200,675,true);add_image_size('card-md',600,340,true);
  register_nav_menus(['primary'=>'Primary Navigation','mobile'=>'Mobile Navigation']);
}
add_action('after_setup_theme','ds_setup');

function ds_scripts(){
  wp_enqueue_style('gfonts','https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700;9..40,800&display=swap',[],null);
  wp_enqueue_style('ds-style',get_stylesheet_uri(),[],'3.0.0');
  wp_enqueue_script('ds-main',get_template_directory_uri().'/js/main.js',[],'3.0.0',true);
  if(is_singular()&&comments_open())wp_enqueue_script('comment-reply');
}
add_action('wp_enqueue_scripts','ds_scripts');

function ds_head(){$id=get_theme_mod('ds_adsense_id','');if($id)echo '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client='.esc_attr($id).'" crossorigin="anonymous"></script>';}
add_action('wp_head','ds_head');

function ds_widgets(){register_sidebar(['name'=>'Sidebar','id'=>'sidebar-1','before_widget'=>'<div class="sw">','after_widget'=>'</div>','before_title'=>'<div class="sw-h"><div class="sw-bar"></div><h3 class="sw-t">','after_title'=>'</h3></div>']);}
add_action('widgets_init','ds_widgets');

function ds_cust($c){
  $c->add_section('ds_ads',['title'=>'Google AdSense','priority'=>120]);
  foreach(['ds_adsense_id'=>'AdSense Client ID','ds_ad_header'=>'Header Ad Slot','ds_ad_sidebar'=>'Sidebar Ad Slot','ds_ad_article'=>'In-Article Ad Slot'] as $k=>$l){
    $c->add_setting($k,['default'=>'','sanitize_callback'=>'sanitize_text_field']);
    $c->add_control($k,['label'=>$l,'section'=>'ds_ads','type'=>'text']);
  }
  $c->add_section('ds_tk',['title'=>'Breaking News','priority'=>110]);
  $c->add_setting('ds_tk_on',['default'=>false,'sanitize_callback'=>'wp_validate_boolean']);
  $c->add_control('ds_tk_on',['label'=>'Enable Ticker','section'=>'ds_tk','type'=>'checkbox']);
  $c->add_setting('ds_tk_txt',['default'=>'','sanitize_callback'=>'sanitize_text_field']);
  $c->add_control('ds_tk_txt',['label'=>'Ticker Text','section'=>'ds_tk','type'=>'text']);
}
add_action('customize_register','ds_cust');

function ds_ad($s,$sz='lb'){
  $sl=get_theme_mod($s,'');$cl=get_theme_mod('ds_adsense_id','');
  if($sl&&$cl){echo '<div class="ad ad-'.$sz.'"><ins class="adsbygoogle" style="display:block" data-ad-client="'.esc_attr($cl).'" data-ad-slot="'.esc_attr($sl).'" data-ad-format="auto" data-full-width-responsive="true"></ins><script>(adsbygoogle=window.adsbygoogle||[]).push({});</script></div>';}
  else{echo '<div class="ad ad-'.$sz.'"><span>Advertisement</span></div>';}
}
function ds_badge($c=null){if(!$c){$cs=get_the_category();if(empty($cs))return;$c=$cs[0];}$s=is_object($c)?$c->slug:sanitize_title($c);$n=is_object($c)?$c->name:$c;echo '<span class="cb cb-'.esc_attr($s).'">'.esc_html($n).'</span>';}
function ds_ago(){echo human_time_diff(get_the_time('U'),current_time('timestamp')).' ago';}
function ds_rt(){echo max(1,ceil(str_word_count(strip_tags(get_post_field('post_content',get_the_ID())))/200)).' min read';}
add_filter('excerpt_length',function(){return 22;});
add_filter('excerpt_more',function(){return '...';});
function ds_force_blog($q){if($q->is_main_query()&&is_front_page()&&is_page()){$q->set('post_type','post');$q->set('page_id','');$q->is_page=false;$q->is_home=true;$q->is_singular=false;}}
add_action('pre_get_posts','ds_force_blog');
function ds_fallback_nav(){echo '<a href="'.home_url('/').'">Home</a>';foreach(get_categories(['number'=>6,'hide_empty'=>false])as$c)echo '<a href="'.get_category_link($c->term_id).'">'.esc_html($c->name).'</a>';}
