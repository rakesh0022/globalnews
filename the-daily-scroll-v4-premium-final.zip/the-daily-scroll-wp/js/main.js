document.addEventListener('DOMContentLoaded',function(){
  var t=document.getElementById('tBtn'),s=t?t.querySelector('.is'):null,m=t?t.querySelector('.im'):null;
  function u(){var d=document.documentElement.classList.contains('dark-mode');if(s)s.style.display=d?'none':'block';if(m)m.style.display=d?'block':'none'}
  u();if(t)t.addEventListener('click',function(){document.documentElement.classList.toggle('dark-mode');localStorage.setItem('ds_dk',document.documentElement.classList.contains('dark-mode')?'1':'0');u()});

  var mb=document.getElementById('mBtn'),mm=document.getElementById('mm'),mo=document.getElementById('mmOv'),mx=document.getElementById('mmX');
  function om(){if(mm)mm.classList.add('active');document.body.style.overflow='hidden'}
  function cm(){if(mm)mm.classList.remove('active');document.body.style.overflow=''}
  if(mb)mb.addEventListener('click',om);if(mo)mo.addEventListener('click',cm);if(mx)mx.addEventListener('click',cm);

  var sb=document.getElementById('sBtn'),sv=document.getElementById('sov'),sx=document.getElementById('sovX'),si=sv?sv.querySelector('input'):null;
  function os(){if(sv)sv.classList.add('active');if(si)si.focus();document.body.style.overflow='hidden'}
  function cs(){if(sv)sv.classList.remove('active');document.body.style.overflow=''}
  if(sb)sb.addEventListener('click',os);if(sx)sx.addEventListener('click',cs);
  if(sv)sv.addEventListener('click',function(e){if(e.target===sv)cs()});

  document.addEventListener('keydown',function(e){if(e.key==='Escape'){cs();cm()}});

  var h=document.getElementById('hdr');
  window.addEventListener('scroll',function(){if(h)h.classList.toggle('scrolled',window.scrollY>10)},{passive:true});

  var rb=document.getElementById('rbar');
  if(rb)window.addEventListener('scroll',function(){var d=document.documentElement.scrollHeight-window.innerHeight;rb.style.width=(d>0?(window.scrollY/d)*100:0)+'%'},{passive:true});

  if('IntersectionObserver'in window){var els=document.querySelectorAll('.au');if(els.length){var ob=new IntersectionObserver(function(en){en.forEach(function(e){if(e.isIntersecting){e.target.style.opacity='1';e.target.style.transform='translateY(0)';ob.unobserve(e.target)}})},{threshold:.1});els.forEach(function(el){el.style.opacity='0';el.style.transform='translateY(12px)';el.style.transition='opacity .4s ease,transform .4s ease';ob.observe(el)})}}
});
