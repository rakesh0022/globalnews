<?php get_header();?><div class="container"><?php if(have_posts()):while(have_posts()):the_post();?>
<div class="ph au"><div class="ph-lb"><div class="ph-bar"></div><span>Page</span></div><h1><?php the_title();?></h1></div>
<div class="pb"><?php the_content();?></div>
<?php endwhile;endif;?></div><?php get_footer();?>
