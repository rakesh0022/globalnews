</main><footer class="site-footer"><div class="container">
<div class="ftg">
<div class="ftc"><h4>Categories</h4><?php foreach(get_categories(['number'=>6,'hide_empty'=>false])as$c)echo '<a href="'.get_category_link($c->term_id).'">'.esc_html($c->name).'</a>';?></div>
<div class="ftc"><h4>Features</h4><a href="<?php echo home_url('/');?>">Home</a><a href="<?php echo home_url('/?s=');?>">Search</a><a href="#">Newsletter</a></div>
<div class="ftc"><h4>Company</h4><a href="<?php echo home_url('/about/');?>">About</a><a href="<?php echo home_url('/contact/');?>">Contact</a></div>
<div class="ftc"><h4>Legal</h4><a href="<?php echo home_url('/privacy-policy/');?>">Privacy</a><a href="<?php echo home_url('/terms-of-service/');?>">Terms</a><a href="<?php echo home_url('/disclaimer/');?>">Disclaimer</a><a href="<?php echo home_url('/dmca/');?>">DMCA</a></div>
</div>
<div class="ftb">
<a href="<?php echo home_url('/');?>" class="site-logo" style="gap:7px"><div class="logo-icon" style="width:24px;height:24px;border-radius:8px"><svg xmlns="http://www.w3.org/2000/svg" style="width:12px;height:12px" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/></svg></div><span class="logo-text" style="font-size:14px">Daily<span class="gt">Scroll</span></span></a>
<span class="ftcp">&copy; <?php echo date('Y');?> The Daily Scroll by Suraj Pandey</span>
<div class="ftl"><a href="<?php echo home_url('/privacy-policy/');?>">Privacy</a><a href="<?php echo home_url('/terms-of-service/');?>">Terms</a><a href="<?php echo home_url('/contact/');?>">Contact</a></div>
</div></div></footer><?php wp_footer();?></body></html>
