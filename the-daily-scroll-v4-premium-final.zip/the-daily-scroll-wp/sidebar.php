<?php if(is_active_sidebar('sidebar-1')):echo '<div>';dynamic_sidebar('sidebar-1');echo '</div>';else:?>
<div class="sw"><div class="sw-h"><div class="sw-bar"></div><h3 class="sw-t">Trending Now 🔥</h3></div><div class="sw-b"><?php
$tr=new WP_Query(['posts_per_page'=>5,'orderby'=>'date','order'=>'DESC']);$r=0;
while($tr->have_posts()):$tr->the_post();$r++;?>
<div class="ti"><div class="ti-r"><?php echo $r;?></div><div style="flex:1;min-width:0"><div class="ti-t"><a href="<?php the_permalink();?>"><?php the_title();?></a></div><div class="ti-m"><?php ds_badge();?> · <?php ds_ago();?></div></div></div>
<?php endwhile;wp_reset_postdata();?></div></div>
<?php ds_ad('ds_ad_sidebar','sb');?>
<div class="nlw"><h3>📬 Get the Daily Scroll</h3><p>Facts and stories delivered to your inbox every morning.</p><div class="nlf"><input type="email" class="nli" placeholder="Your email..."><button class="nlb">Subscribe</button></div></div>
<div class="sw"><div class="sw-h"><div class="sw-bar"></div><h3 class="sw-t">Browse Topics 🗂️</h3></div><div class="sw-b"><div class="tp-grid"><?php
$emojis=['technology'=>'⚡','sports'=>'⚽','business'=>'📈','health'=>'❤️','science'=>'🔬','entertainment'=>'🎬','photography'=>'📸','design'=>'🎨','digital'=>'💻','film'=>'🎬','advertising'=>'📢','podcasts'=>'🎙️'];
foreach(get_categories(['hide_empty'=>false,'number'=>10])as$c):$e=isset($emojis[$c->slug])?$emojis[$c->slug]:'📄';?>
<a href="<?php echo get_category_link($c->term_id);?>" class="tp-pill"><span><?php echo $e;?></span><?php echo esc_html($c->name);?><span class="cnt"><?php echo $c->count;?></span></a>
<?php endforeach;?></div></div></div>
<?php endif;?>
