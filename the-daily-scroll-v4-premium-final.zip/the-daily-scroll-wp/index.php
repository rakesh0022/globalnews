<?php get_header();?>
<div class="container">
<?php if((is_front_page()||is_home())&&!is_paged()):
$h=new WP_Query(['posts_per_page'=>3,'ignore_sticky_posts'=>false]);
if($h->have_posts()):$i=0;?>
<section class="hero"><div class="hero-grid">
<?php while($h->have_posts()):$h->the_post();$i++;if($i===1):?>
<div class="hero-main"><?php if(has_post_thumbnail()):the_post_thumbnail('hero-lg');else:?><div style="position:absolute;inset:0;background:linear-gradient(135deg,#1e293b,#334155)"></div><?php endif;?>
<div class="hc"><?php ds_badge();?><h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2><div class="hm"><span><?php the_author();?></span><span style="opacity:.5">·</span><span><?php ds_ago();?></span><span style="opacity:.5">·</span><span><?php ds_rt();?></span></div></div></div>
<?php else:?><div class="hero-side"><?php if(has_post_thumbnail()):the_post_thumbnail('card-md');else:?><div style="position:absolute;inset:0;background:linear-gradient(135deg,#1e293b,#475569)"></div><?php endif;?>
<div class="hc"><h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3><div class="hm"><?php ds_ago();?></div></div></div>
<?php endif;endwhile;?></div></section>
<?php wp_reset_postdata();endif;ds_ad('ds_ad_header','lb');endif;?>

<div class="lms"><div>
<?php if((is_front_page()||is_home())&&!is_paged()):?><div class="sh"><div class="sh-l"><div class="sh-bar"></div><span style="font-size:17px">📰</span><h2 class="sh-t">Latest Stories</h2></div></div>
<?php elseif(is_search()):?><div class="ah au"><h1>Results for "<?php echo get_search_query();?>"</h1><p style="color:var(--mut);margin-top:4px"><?php global $wp_query;echo $wp_query->found_posts;?> found</p></div>
<?php elseif(is_archive()):?><div class="ah au"><div style="display:flex;align-items:center;gap:7px;margin-bottom:8px"><div style="width:4px;height:24px;border-radius:4px;background:var(--grad)"></div><span style="font-size:11px;font-weight:800;color:var(--acc);text-transform:uppercase;letter-spacing:.12em"><?php echo is_category()?'Category':(is_tag()?'Tag':'Archive');?></span></div><h1><?php the_archive_title();?></h1></div>
<?php endif;?>

<?php if(have_posts()):?><div class="g3">
<?php $sk=(is_front_page()||is_home())&&!is_paged()?3:0;$s=0;while(have_posts()):the_post();if($s<$sk){$s++;continue;}?>
<article class="card au"><div class="card-i"><a href="<?php the_permalink();?>"><?php if(has_post_thumbnail()):the_post_thumbnail('card-md');else:?><div class="nt">No Image</div><?php endif;?></a></div>
<div class="card-b"><div><?php ds_badge();?></div><h3 class="card-t"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3><p class="card-e"><?php echo get_the_excerpt();?></p>
<div class="card-m"><span><?php the_author();?></span><span class="d"></span><span><?php ds_ago();?></span><span class="d"></span><span><?php ds_rt();?></span></div></div></article>
<?php endwhile;?></div>
<div class="pagination"><?php the_posts_pagination(['mid_size'=>2,'prev_text'=>'← Prev','next_text'=>'Next →']);?></div>
<?php else:?><div style="text-align:center;padding:50px 0"><div style="font-size:42px;margin-bottom:12px">📭</div><h2 style="font-size:18px;margin-bottom:5px">No posts found</h2><p style="color:var(--mut)">Try a different search.</p></div><?php endif;?>
</div><aside><?php get_sidebar();?></aside></div>
</div>
<?php get_footer();?>
