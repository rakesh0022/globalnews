<?php if(is_active_sidebar('sidebar-1')): dynamic_sidebar('sidebar-1'); else: ?>
<div class="sw">
  <div class="sw__head"><div class="sw__bar"></div><h3 class="sw__ttl">Trending Now 🔥</h3></div>
  <div class="sw__body"><?php
    $tr=new WP_Query(['posts_per_page'=>5,'orderby'=>'comment_count','order'=>'DESC']);
    $r=0; while($tr->have_posts()): $tr->the_post(); $r++; ?>
    <div class="trend-item"><div class="trend-rank"><?php echo $r; ?></div><div><div class="trend-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div><div class="trend-meta"><?php ds_ago(); ?></div></div></div>
  <?php endwhile; wp_reset_postdata(); ?></div>
</div>
<?php ds_ad('ds_ad_sidebar','sb'); ?>
<div class="nl-widget">
  <h3>📬 Get the Daily Scroll</h3>
  <p>Join readers who get the best facts delivered every morning.</p>
  <div class="nl-form"><input type="email" class="nl-input" placeholder="Your email..."><button class="nl-btn">Subscribe</button></div>
</div>
<?php endif; ?>
